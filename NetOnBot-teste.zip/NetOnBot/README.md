# NET ON Bot — primeiro robô de teste (Fase 1)

## Abrir
1. Android Studio → File > Open → escolha esta pasta (NetOnBot). Espere o "Sync".
2. Ligue um telemóvel Android (Depuração USB) ou use um emulador.
3. Botão Run (triângulo verde).

## Teste 1 — simulação (não gasta nada)
1. Aceite as permissões.
2. Aba Pacotes → "Carregar exemplos do documento".
3. Aba SIMs → "SIM de teste".
4. Aba Painel → ligue "Bot ligado" (Modo simulação fica LIGADO).
5. Aba Testar → "Simular SMS recebido" com o exemplo "e-Mola 10 MT com número".
6. Aba Pedidos → o pedido deve ficar CONCLUIDO. Aba Painel → registo mostra o SMS simulado.
7. Experimente os outros exemplos (sem número, M-Pesa, fora da tabela, semanal).
   Clique "Gerar IDs novos" entre testes (o mesmo ID é recusado de propósito: anti-duplicação).

## Teste 2 — real, com 100 MB para um número SEU
1. Aba SIMs → "Detetar SIMs" (confirme que o SIM Vodacom aparece como vodacom).
2. Painel → "Acessibilidade" → ative "NET ON Bot (teste)". Painel → "Bateria" → permita sem restrições.
3. Aba Pacotes → crie um pacote de teste: ex. 1 MT = 100 MB (diário).
4. Desligue o Modo simulação.
5. De OUTRO telemóvel, pague 1 MT por e-Mola ao seu número, com o seu número Vodacom no campo Conteúdo.
6. Veja o Painel (registo) e os Pedidos.

## Testes automáticos
- Unitários (no computador): clique direito em app/src/test → Run Tests.
- Executor (precisa de emulador/telemóvel): app/src/androidTest → Run.

## Gerar o APK sem Android Studio (GitHub)
1. Crie uma conta e um repositório novo em github.com.
2. Envie todo o conteúdo desta pasta (incluindo .github/workflows/build.yml).
3. Separador Actions → "Gerar APK" → Run workflow. Espere ~5 min.
4. Abra a execução concluída → Artifacts → NetOnBot-apk → descarregue, extraia e instale o app-debug.apk.
(No Android Studio: Build > Build Bundle(s)/APK(s) > Build APK(s).)
