package mz.neton

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        // SMS longos chegam em partes: junta por remetente.
        val porRemetente = msgs.groupBy { it.originatingAddress.orEmpty() }
            .mapValues { (_, partes) -> partes.joinToString("") { it.messageBody.orEmpty() } }

        val app = context.applicationContext as App
        val pr = goAsync()
        app.scope.launch {
            try {
                porRemetente.forEach { (r, corpo) -> app.bot.aoReceberSms(r.ifEmpty { null }, corpo) }
            } catch (e: Exception) {
                app.bot.log("ERRO", "SMS: ${e.message}")
            } finally {
                pr.finish()
            }
            app.bot.acordarFila()   // o USSD é lento: corre fora do receptor
        }
    }
}
