package mz.neton.engine

import android.content.Context
import androidx.room.withTransaction
import kotlinx.coroutines.sync.Mutex
import mz.neton.data.*
import mz.neton.ussd.Ambiguo
import mz.neton.ussd.DecisaoAmbiguo
import mz.neton.ussd.FormatoDestino
import mz.neton.ussd.ResultadoUssd
import mz.neton.ussd.Tarefa
import mz.neton.ussd.UssdBridge

/** Quem corre o USSD. Em produção é a UssdBridge; nos testes é um falso. */
interface UssdRunner {
    suspend fun executar(tarefa: Tarefa, subId: Int): ResultadoUssd
}

class UssdBridgeRunner(
    private val ctx: Context,
    private val formato: () -> FormatoDestino = { FormatoDestino.NOVE_DIGITOS }
) : UssdRunner {
    override suspend fun executar(tarefa: Tarefa, subId: Int) = UssdBridge.executar(ctx, tarefa, subId, formato())
}

/** Variáveis: {DESCRICAO} {DESTINO} {ID} {NEGOCIO} */
data class MensagensExec(
    val sucesso: String = "TRANSFERÊNCIA CONCLUÍDA: {DESCRICAO} enviados para {DESTINO}. {NEGOCIO}",
    val falha: String = "Não foi possível concluir a transferência (ref. {ID}). O administrador foi avisado. {NEGOCIO}",
    val emAnalise: String = "A sua transferência (ref. {ID}) está em verificação pelo administrador. {NEGOCIO}"
)

data class ExecSettings(
    val negocio: String = "",
    val custoPorGbCentavos: Long = 0,          // ex.: 17,61 MT/GB → 1761
    val maxSimsPorPedido: Int = 3,
    val pausaSemSimMs: Long = 5 * 60_000L,     // sem SIM com saldo/quota: espera antes de voltar a tentar
    val alertaSemSimMs: Long = 30 * 60_000L,   // intervalo mínimo entre alertas ao dono
    val msg: MensagensExec = MensagensExec()
)

private enum class Desfecho { CONCLUIDO, REVISAO, OUTRO_SIM_SALDO, OUTRO_SIM_FALHA }

/**
 * Regras de ouro:
 * 1. Nunca reenvia por outro SIM se existir QUALQUER dúvida de que os megas já saíram.
 * 2. Dúvida → REVISAO (o dono decide). Dinheiro da carteira fica reservado.
 * 3. Falha confirmada → devolve quota do SIM e (carteira) estorna a reserva.
 */
class Executor(
    private val db: AppDatabase,
    private val runner: UssdRunner,
    private val efeitos: Efeitos,
    private val cfg: () -> ExecSettings,
    private val agora: () -> Long = System::currentTimeMillis
) {
    private val mutex = Mutex()
    private var pausaAte = 0L
    private var ultimoAlertaSemSim = 0L

    // ───────────── Fila ─────────────

    /** Chamar de tempos a tempos (ex.: cada 15 s) e sempre que entra um pedido novo. */
    suspend fun processarFila() {
        if (!mutex.tryLock()) return           // já está a correr
        try {
            if (agora() < pausaAte) return
            while (true) {
                val proximo = db.pedidos().porEstado(EstadoPedido.NA_FILA).firstOrNull() ?: break
                if (!executar(proximo)) break
            }
        } finally {
            mutex.unlock()
        }
    }

    /** Chamar ao arrancar a app: o que ficou "em execução" não se sabe se saiu → revisão, nunca reenvio. */
    suspend fun recuperarAposReinicio() {
        val now = agora()
        for (p in db.pedidos().porEstado(EstadoPedido.EM_EXECUCAO)) {
            marcarRevisao(p, "A app reiniciou durante a execução do USSD.", EstadoPedido.EM_EXECUCAO)
        }
    }

    // ───────────── Um pedido ─────────────

    /** @return false = não foi possível por falta de SIM; parar o ciclo. */
    private suspend fun executar(p: PedidoEntity): Boolean {
        val s = cfg()
        if (db.pedidos().mudarEstado(p.id, EstadoPedido.NA_FILA, EstadoPedido.EM_EXECUCAO, agora()) == 0) return true

        val tarefa = try {
            Tarefa.Transferir(p.mb, p.destino)
        } catch (e: IllegalArgumentException) {
            falhaDefinitiva(p, "Pedido inválido para esta receita: ${e.message}")
            return true
        }

        val tentados = mutableSetOf<Int>()
        var falhaReal = false
        while (tentados.size < s.maxSimsPorPedido) {
            val sim = escolherSim(tentados) ?: break
            tentados += sim.subId
            db.pedidos().registarTentativa(p.id, sim.subId, null, agora())

            val r = runner.executar(tarefa, sim.subId)
            when (interpretar(p, sim, r)) {
                Desfecho.CONCLUIDO, Desfecho.REVISAO -> return true
                Desfecho.OUTRO_SIM_SALDO -> Unit
                Desfecho.OUTRO_SIM_FALHA -> falhaReal = true
            }
        }

        if (falhaReal) {
            falhaDefinitiva(p, "Falhou em ${tentados.size} SIM(s).")
            return true
        }
        // Só faltou saldo ou quota: o pedido espera na fila (sem reembolso) e o dono é avisado.
        db.pedidos().mudarEstado(p.id, EstadoPedido.EM_EXECUCAO, EstadoPedido.NA_FILA, agora())
        pausaAte = agora() + s.pausaSemSimMs
        if (agora() - ultimoAlertaSemSim >= s.alertaSemSimMs) {
            ultimoAlertaSemSim = agora()
            efeitos.avisarDono("Nenhum SIM com megas ou quota para o pedido #${p.id} (${p.mb} MB). Pedidos a aguardar na fila.")
        }
        return false
    }

    private suspend fun escolherSim(tentados: Set<Int>): SimEntity? {
        val hoje = Dia.hoje(agora())
        for (sim in db.sims().ativos()) {
            if (sim.subId in tentados) continue
            if (!sim.operadora.equals("vodacom", ignoreCase = true)) continue   // a receita é só Vodacom
            if (db.sims().reservarQuota(sim.subId, hoje)) return sim
        }
        return null
    }

    // ───────────── Interpretar o resultado do USSD ─────────────

    private suspend fun interpretar(p: PedidoEntity, sim: SimEntity, r: ResultadoUssd): Desfecho = when (r) {
        is ResultadoUssd.Sucesso -> {
            concluir(p, sim.subId, r.saldoAntesMb, EstadoPedido.EM_EXECUCAO)
            Desfecho.CONCLUIDO
        }
        is ResultadoUssd.SaldoInsuficiente -> {
            db.sims().devolverQuota(sim.subId)
            db.sims().atualizarSaldo(sim.subId, r.saldoMb)
            Desfecho.OUTRO_SIM_SALDO
        }
        is ResultadoUssd.RecusadoAntesDoDestino -> {
            db.sims().devolverQuota(sim.subId)
            log("WARN", "Recusado antes do destino (SIM ${sim.subId}): ${r.ecra}")
            Desfecho.OUTRO_SIM_FALHA
        }
        is ResultadoUssd.Divergente -> {
            marcarRevisao(p, "O ecrã de sucesso não bate com o pedido: ${r.ecra}", EstadoPedido.EM_EXECUCAO)
            Desfecho.REVISAO
        }
        is ResultadoUssd.Ambiguo -> resolverIncerto(p, sim, r.saldoAntesMb, "Ecrã ambíguo: ${r.ecra}")
        is ResultadoUssd.TempoEsgotado ->
            if (r.enviouDestino) resolverIncerto(p, sim, r.saldoAntesMb, "Tempo esgotado depois de enviar o destino.")
            else { db.sims().devolverQuota(sim.subId); Desfecho.OUTRO_SIM_FALHA }
        is ResultadoUssd.Desconhecido -> {
            log("WARN", "Ecrã não reconhecido (SIM ${sim.subId}, destino enviado=${r.enviouDestino}): ${r.ecra}")
            if (r.enviouDestino) resolverIncerto(p, sim, r.saldoAntesMb, "Ecrã não reconhecido: ${r.ecra}")
            else { db.sims().devolverQuota(sim.subId); Desfecho.OUTRO_SIM_FALHA }
        }
        is ResultadoUssd.Saldo -> {   // não esperado numa transferência
            db.sims().devolverQuota(sim.subId)
            Desfecho.OUTRO_SIM_FALHA
        }
    }

    /** Pode ou não ter transferido: lê o saldo outra vez e compara com o de antes. */
    private suspend fun resolverIncerto(p: PedidoEntity, sim: SimEntity, saldoAntes: Int?, motivo: String): Desfecho {
        val leitura = runner.executar(Tarefa.ConsultarSaldo, sim.subId)
        val depois = (leitura as? ResultadoUssd.Saldo)?.mb
        return when (Ambiguo.decidir(saldoAntes, depois, p.mb)) {
            DecisaoAmbiguo.SUCESSO -> {
                concluir(p, sim.subId, saldoAntes, EstadoPedido.EM_EXECUCAO)
                Desfecho.CONCLUIDO
            }
            DecisaoAmbiguo.FALHA -> {
                db.sims().devolverQuota(sim.subId)
                if (depois != null) db.sims().atualizarSaldo(sim.subId, depois)
                Desfecho.OUTRO_SIM_FALHA
            }
            DecisaoAmbiguo.REVISAO -> {
                marcarRevisao(p, "$motivo Saldo antes=$saldoAntes, depois=$depois.", EstadoPedido.EM_EXECUCAO)
                Desfecho.REVISAO
            }
        }
    }

    // ───────────── Desfechos (cada um numa transação) ─────────────

    private suspend fun concluir(p: PedidoEntity, simSubId: Int?, saldoAntes: Int?, esperado: EstadoPedido) {
        val now = agora()
        val s = cfg()
        val custo = p.mb.toLong() * s.custoPorGbCentavos / 1024
        val lucro = if (p.semPagamento) -custo else p.valorCentavos - custo
        db.withTransaction {
            db.pedidos().registarResultado(p.id, "Sucesso", custo, lucro, now)
            db.pedidos().mudarEstado(p.id, esperado, EstadoPedido.CONCLUIDO, now)
            p.pagamentoChave?.let { db.pagamentos().mudarEstado(it, estadoPagAtual(esperado), EstadoPagamento.CONCLUIDO, now) }
            if (simSubId != null && saldoAntes != null) db.sims().atualizarSaldo(simSubId, maxOf(0, saldoAntes - p.mb))
        }
        responder(p, s.msg.sucesso)
    }

    private suspend fun marcarRevisao(p: PedidoEntity, motivo: String, esperado: EstadoPedido) {
        val now = agora()
        val s = cfg()
        var mudou = false
        db.withTransaction {
            db.pedidos().registarResultado(p.id, motivo, 0, 0, now)
            mudou = db.pedidos().mudarEstado(p.id, esperado, EstadoPedido.REVISAO, now) == 1
            if (mudou) p.pagamentoChave?.let { db.pagamentos().mudarEstado(it, EstadoPagamento.USADO, EstadoPagamento.REVISAO, now) }
        }
        if (!mudou) return
        efeitos.avisarDono("Pedido #${p.id} precisa de revisão (${p.mb} MB para ${p.destino}). $motivo")
        responder(p, s.msg.emAnalise)
    }

    private suspend fun falhaDefinitiva(p: PedidoEntity, motivo: String) {
        val now = agora()
        val s = cfg()
        db.withTransaction {
            db.pedidos().registarResultado(p.id, motivo, 0, 0, now)
            db.pedidos().mudarEstado(p.id, EstadoPedido.EM_EXECUCAO, EstadoPedido.FALHOU, now)
            p.pagamentoChave?.let { db.pagamentos().mudarEstado(it, EstadoPagamento.USADO, EstadoPagamento.FALHOU, now) }
            if (p.canal == Canal.CARTEIRA) db.carteira().estornar(p.id, now)   // devolve o saldo reservado
        }
        efeitos.avisarDono("Pedido #${p.id} FALHOU (${p.mb} MB para ${p.destino}). $motivo")
        responder(p, s.msg.falha)
    }

    // ───────────── Ações do dono ─────────────

    /** Botão "Reenviar": só para falhas confirmadas e que não vieram da carteira (essas o cliente pede de novo). */
    suspend fun reenviar(pedidoId: Long): Boolean {
        val p = db.pedidos().porId(pedidoId) ?: return false
        if (p.canal == Canal.CARTEIRA) return false
        val now = agora()
        var ok = false
        db.withTransaction {
            if (db.pedidos().mudarEstado(pedidoId, EstadoPedido.FALHOU, EstadoPedido.NA_FILA, now) == 1) {
                p.pagamentoChave?.let { db.pagamentos().mudarEstado(it, EstadoPagamento.FALHOU, EstadoPagamento.USADO, now) }
                ok = true
            }
        }
        return ok
    }

    /** O dono verificou no telemóvel de destino: os megas chegaram (true) ou não (false). */
    suspend fun resolverRevisao(pedidoId: Long, entregue: Boolean): Boolean {
        val p = db.pedidos().porId(pedidoId) ?: return false
        if (p.estado != EstadoPedido.REVISAO) return false
        if (entregue) {
            concluir(p, p.simSubId, null, EstadoPedido.REVISAO)
        } else {
            val now = agora()
            db.withTransaction {
                db.pedidos().mudarEstado(pedidoId, EstadoPedido.REVISAO, EstadoPedido.FALHOU, now)
                p.pagamentoChave?.let { db.pagamentos().mudarEstado(it, EstadoPagamento.REVISAO, EstadoPagamento.FALHOU, now) }
                if (p.canal == Canal.CARTEIRA) db.carteira().estornar(pedidoId, now)
            }
            responder(p, cfg().msg.falha)
        }
        return true
    }

    // ───────────── Util ─────────────

    private fun estadoPagAtual(esperadoPedido: EstadoPedido) =
        if (esperadoPedido == EstadoPedido.REVISAO) EstadoPagamento.REVISAO else EstadoPagamento.USADO

    private suspend fun responder(p: PedidoEntity, modelo: String) {
        val cliente = p.clienteNumero ?: return
        val s = cfg()
        val texto = modelo
            .replace("{DESCRICAO}", "${p.mb} MB")
            .replace("{DESTINO}", p.destino.removePrefix("258"))
            .replace("{ID}", p.pagamentoChave?.substringAfter(':') ?: "#${p.id}")
            .replace("{NEGOCIO}", s.negocio)
            .replace(Regex("[ \\t]{2,}"), " ")
            .trim()
        when (p.canal) {
            Canal.GRUPO, Canal.CARTEIRA -> {
                val grupo = p.pagamentoChave?.let { db.pagamentos().porChave(it)?.grupoId }
                efeitos.responderGrupo(grupo, cliente, texto)
            }
            else -> efeitos.enviarSms(cliente, texto)
        }
    }

    private suspend fun log(nivel: String, msg: String) {
        db.logs().inserir(LogEntity(nivel = nivel, origem = "ussd", mensagem = msg.take(2000), criadoEm = agora()))
    }
}
