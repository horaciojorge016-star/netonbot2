package mz.neton

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Mantém o bot vivo em segundo plano: prazos (10 min) e fila de pedidos de 15 em 15 s. */
class BotService : Service() {

    private var job: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        criarCanal()
        ServiceCompat.startForeground(
            this, 1, notificacao(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "netonbot:servico").apply { acquire() }
        }
        if (job == null) {
            val app = application as App
            job = app.scope.launch {
                while (isActive) {
                    try { app.bot.ciclo() } catch (e: Exception) { app.bot.log("ERRO", "Ciclo: ${e.message}") }
                    delay(15_000)
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        job?.cancel(); job = null
        wakeLock?.let { if (it.isHeld) it.release() }; wakeLock = null
        super.onDestroy()
    }

    private fun criarCanal() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "Bot ativo", NotificationManager.IMPORTANCE_LOW))
    }

    private fun notificacao(): Notification =
        NotificationCompat.Builder(this, "bot")
            .setContentTitle("NET ON Bot ativo")
            .setContentText(if ((application as App).config.simulacao) "Modo simulação" else "A atender pedidos")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()

    companion object {
        fun iniciar(ctx: Context) =
            ContextCompat.startForegroundService(ctx, Intent(ctx, BotService::class.java))

        fun parar(ctx: Context) {
            ctx.stopService(Intent(ctx, BotService::class.java))
        }
    }
}
