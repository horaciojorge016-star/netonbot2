package mz.neton.ussd

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Liga a lógica pura (SessaoUssd) ao Android.
 * ATENÇÃO: não foi testado em aparelho. Os pacotes do diálogo USSD variam por marca:
 * se nada acontecer, veja `pacotesIgnorados` e acrescente o pacote a `pacotesUssd`.
 */
object UssdBridge {
    private val mutex = Mutex()                        // um USSD de cada vez por aparelho

    @Volatile private var sessao: SessaoUssd? = null
    @Volatile private var pendente: CompletableDeferred<ResultadoUssd>? = null

    val pacotesUssd: MutableSet<String> = mutableSetOf(
        "com.android.phone",
        "com.android.server.telecom",
        "com.samsung.android.incallui",
        "com.samsung.android.dialer",
        "com.google.android.dialer"
    )
    val pacotesIgnorados: MutableSet<String> = mutableSetOf()   // para diagnóstico

    fun ativa(): Boolean = sessao != null

    suspend fun executar(
        ctx: Context,
        tarefa: Tarefa,
        subId: Int?,
        formato: FormatoDestino = FormatoDestino.NOVE_DIGITOS,
        codigo: String = "*162#",
        timeoutMs: Long = 60_000
    ): ResultadoUssd = mutex.withLock {
        val s = SessaoUssd(tarefa, formato)
        val d = CompletableDeferred<ResultadoUssd>()
        sessao = s
        pendente = d
        try {
            UssdDialer.discar(ctx, codigo, subId)
            withTimeoutOrNull(timeoutMs) { d.await() } ?: s.aoExpirar()
        } finally {
            sessao = null
            pendente = null
        }
    }

    /** Chamado pelo serviço de acessibilidade a cada ecrã lido. */
    fun aoVerEcra(texto: String): Passo? {
        val s = sessao ?: return null
        val p = s.aoVerEcra(texto)
        if (p is Passo.Terminar) pendente?.complete(p.resultado)
        return p
    }

    /** O serviço não conseguiu escrever ou clicar. */
    fun interacaoFalhou(texto: String) {
        val s = sessao ?: return
        pendente?.complete(s.aoFalharInteracao(texto))
    }
}

object UssdDialer {
    /** Precisa das permissões CALL_PHONE e READ_PHONE_STATE. subId = SIM a usar (null = SIM por omissão). */
    @SuppressLint("MissingPermission")
    fun discar(ctx: Context, codigo: String, subId: Int?) {
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(codigo)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (subId != null) {
            handleDoSim(ctx, subId)?.let { intent.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, it) }
        }
        ctx.startActivity(intent)
    }

    @SuppressLint("MissingPermission")
    private fun handleDoSim(ctx: Context, subId: Int): PhoneAccountHandle? {
        val tm = ctx.getSystemService(TelecomManager::class.java) ?: return null
        val tel = ctx.getSystemService(TelephonyManager::class.java) ?: return null
        return tm.callCapablePhoneAccounts.firstOrNull { tel.createForPhoneAccountHandle(it)?.subscriptionId == subId }
    }
}

class UssdAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !UssdBridge.ativa()) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg !in UssdBridge.pacotesUssd) {
            UssdBridge.pacotesIgnorados.add(pkg)
            return
        }
        val root = rootInActiveWindow ?: return

        val textos = mutableListOf<String>()
        val campo = arrayOfNulls<AccessibilityNodeInfo>(1)
        percorrer(root, textos, campo)
        if (textos.isEmpty()) return
        val texto = textos.joinToString("\n")

        when (val passo = UssdBridge.aoVerEcra(texto)) {
            is Passo.Enviar -> {
                val ok = campo[0]?.let { escrever(it, passo.texto) } == true && clicar(root, listOf("enviar", "send"))
                if (!ok) UssdBridge.interacaoFalhou(texto)
            }
            is Passo.Terminar -> clicar(root, listOf("ok", "cancelar", "cancel"))
            Passo.Aguardar, null -> Unit
        }
    }

    override fun onInterrupt() = Unit

    /** Junta o texto do diálogo (sem botões nem o campo de escrita) e guarda o campo de escrita. */
    private fun percorrer(no: AccessibilityNodeInfo, textos: MutableList<String>, campo: Array<AccessibilityNodeInfo?>) {
        val cls = no.className?.toString().orEmpty()
        when {
            cls.endsWith("EditText") -> campo[0] = no
            cls.endsWith("Button") -> Unit
            else -> no.text?.toString()?.takeIf { it.isNotBlank() }?.let(textos::add)
        }
        for (i in 0 until no.childCount) no.getChild(i)?.let { percorrer(it, textos, campo) }
    }

    private fun escrever(campo: AccessibilityNodeInfo, texto: String): Boolean {
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, texto)
        }
        return campo.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Clica o primeiro botão cujo texto seja um dos rótulos (por ordem de preferência). */
    private fun clicar(root: AccessibilityNodeInfo, rotulos: List<String>): Boolean {
        for (r in rotulos) {
            for (no in root.findAccessibilityNodeInfosByText(r)) {
                if (no.text?.toString()?.trim()?.lowercase() != r) continue
                var alvo: AccessibilityNodeInfo? = no
                while (alvo != null && !alvo.isClickable) alvo = alvo.parent
                if (alvo?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
            }
        }
        return false
    }
}
