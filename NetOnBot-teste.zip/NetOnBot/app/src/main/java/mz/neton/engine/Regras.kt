package mz.neton.engine

import mz.neton.data.Familia

enum class Acao {
    PROCESSAR_JA,        // tem pacote + destino → cria pedido
    PEDIR_NUMERO_SMS,    // pede o número por SMS ao pagador (10 min)
    PEDIR_NUMERO_GRUPO,  // pede o número no grupo
    AVISAR_DONO,         // semanal/mensal/diamante sem ativação automática
    CREDITAR_CARTEIRA,   // fora da tabela + cliente identificado no grupo
    SMS_FORA_TABELA      // fora da tabela + só SMS: avisa por SMS, fica SEM_DONO
}

object Regras {

    /**
     * @param familia família do pacote cujo preço é igual ao valor pago (null = fora da tabela)
     * @param autoAtivar famílias com "Ativação Automática" ligada
     * @param temDestino já existe número Vodacom válido (campo Conteudo do e-Mola)
     * @param temCliente o cliente já colou o comprovativo no grupo
     */
    fun proximaAcao(familia: Familia?, autoAtivar: Set<Familia>, temDestino: Boolean, temCliente: Boolean): Acao {
        if (familia == null) {
            return if (temCliente) Acao.CREDITAR_CARTEIRA else Acao.SMS_FORA_TABELA
        }
        val automatico = familia == Familia.DIARIO || familia == Familia.PROMOCAO || familia in autoAtivar
        if (!automatico) return Acao.AVISAR_DONO
        return when {
            temDestino -> Acao.PROCESSAR_JA
            temCliente -> Acao.PEDIR_NUMERO_GRUPO
            else -> Acao.PEDIR_NUMERO_SMS
        }
    }

    private val NUMERO = Regex("""(?:\+?258[\s-]?)?\d{2}[\s-]?\d{3}[\s-]?\d{4}""")

    /** Procura um número de telefone em texto livre ("85 720 7022", "+258857207022", "é o 857207022"). */
    fun extrairNumero(texto: String): String? = NUMERO.find(texto)?.value
}
