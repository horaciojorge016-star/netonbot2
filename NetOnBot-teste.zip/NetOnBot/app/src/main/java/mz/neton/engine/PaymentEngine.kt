package mz.neton.engine

import androidx.room.withTransaction
import mz.neton.data.*
import mz.neton.payments.Origem
import mz.neton.payments.ParsedPayment
import mz.neton.payments.Phone
import java.util.Locale

/** Tudo o que o motor "diz" ao mundo. A app implementa isto (SMS real, WhatsApp real, notificação). */
interface Efeitos {
    suspend fun enviarSms(para: String, texto: String)
    suspend fun responderGrupo(grupoId: String?, cliente: String, texto: String)
    suspend fun avisarDono(texto: String)
}

/** Textos editáveis nas Definições. Variáveis: {VALOR} {ID} {NEGOCIO} {GRUPO} {GRUPO_FRASE} {SALDO} */
data class Mensagens(
    val pedirNumeroSms: String =
        "Recebemos {VALOR} MT (ref. {ID}). Responda a esta mensagem com o número Vodacom (84 ou 85) que vai receber os megas. Tem 10 minutos. {NEGOCIO}",
    val prazoSms: String =
        "Não recebemos o número de destino a tempo (ref. {ID}). Este pedido só poderá ser processado pelo grupo. {GRUPO_FRASE} {NEGOCIO}",
    val numeroInvalidoSms: String =
        "Número inválido. Envie um número Vodacom com 9 dígitos, começando por 84 ou 85. {NEGOCIO}",
    val foraTabelaSms: String =
        "Recebemos {VALOR} MT (ref. {ID}). Este valor não consta da nossa tabela, por isso não será processado automaticamente. {GRUPO_FRASE} {NEGOCIO}",
    val recebidoManualSms: String =
        "Recebemos {VALOR} MT (ref. {ID}). O seu pedido será ativado pelo administrador. {NEGOCIO}",
    val fraseGrupoSaldo: String = "Para guardar como saldo, envie o comprovativo em {GRUPO}.",
    val fraseGrupoPedido: String = "Envie o comprovativo em {GRUPO}.",

    val pedirNumeroGrupo: String = "Comprovativo recebido. Envie o número Vodacom que vai receber os megas.",
    val numeroInvalidoGrupo: String = "Número inválido. Envie um número Vodacom com 9 dígitos, começando por 84 ou 85.",
    val aguardaPagamentoGrupo: String = "Comprovativo recebido. A aguardar a confirmação do pagamento.",
    val naoConfereGrupo: String = "O valor do comprovativo não confere com o pagamento recebido.",
    val jaAtendidoGrupo: String = "Este pagamento já foi atendido.",
    val emAnaliseGrupo: String = "Este pagamento está em análise pelo administrador.",
    val saldoGrupo: String = "Saldo atualizado: {SALDO} MT.",
    val tempoEsgotadoGrupo: String = "Tempo esgotado. O administrador foi avisado.",
    val semPagamentoGrupo: String = "Ainda não encontrámos o pagamento com essa referência. Será processado assim que chegar.",
    val recebidoManualGrupo: String = "Pagamento recebido. O seu pedido será ativado pelo administrador."
)

data class Settings(
    val negocio: String = "",
    val grupo: String = "",                          // nome ou link (configurável)
    val autoAtivar: Set<Familia> = emptySet(),
    val prazoNumeroMs: Long = 10 * 60_000L,          // 10 minutos
    val prazoReclamacaoMs: Long = 24 * 3_600_000L,   // depois disto vai para REVISAO (a confirmar)
    val maxTentativasNumero: Int = 3,
    val msg: Mensagens = Mensagens()
)

class PaymentEngine(
    private val db: AppDatabase,
    private val efeitos: Efeitos,
    private val cfg: () -> Settings,
    private val agora: () -> Long = System::currentTimeMillis
) {
    private val pag get() = db.pagamentos()

    // Se o valor coincidir com várias famílias, esta ordem decide.
    private val ordemFamilias =
        listOf(Familia.PROMOCAO, Familia.DIARIO, Familia.SEMANAL, Familia.MENSAL, Familia.DIAMANTE)

    // ───────────── 1. SMS oficial chegou ao aparelho Central ─────────────

    suspend fun aoReceberSmsOficial(p: ParsedPayment) {
        require(p.origem == Origem.SMS_OFICIAL)
        val now = agora()
        val nova = PagamentoEntity(
            chave = p.chave, operadora = p.operadora, valorCentavos = p.valorCentavos,
            pagadorNumero = p.contraparte, pagadorNome = p.nome, destinoVodacom = p.destinoVodacom,
            conteudoBruto = p.conteudoBruto, smsEm = p.timestampMs, recebidoEm = now,
            estado = EstadoPagamento.DISPONIVEL, atualizadoEm = now
        )
        if (pag.inserir(nova) == -1L) {
            val existente = pag.porChave(p.chave) ?: return
            if (existente.estado != EstadoPagamento.PENDENTE) return   // SMS duplicado: ignora
            // Havia um comprovativo à espera deste SMS.
            val provaConfere = existente.valorCentavos == p.valorCentavos
            val n = pag.confirmarPendente(
                p.chave, p.valorCentavos, p.contraparte, p.nome, p.destinoVodacom, p.conteudoBruto, p.timestampMs, now
            )
            if (n == 0) return
            if (!provaConfere) pag.limparCliente(p.chave, now)         // comprovativo com valor errado: descartado
        }
        decidir(p.chave)
    }

    // ───────────── 2. Comprovativo colado no grupo ─────────────

    suspend fun aoReceberComprovativo(prova: ParsedPayment, cliente: String, grupoId: String?) {
        require(prova.origem == Origem.COMPROVATIVO)
        val s = cfg()
        val now = agora()
        val ex = pag.porChave(prova.chave)

        if (ex == null) {
            val nova = PagamentoEntity(
                chave = prova.chave, operadora = prova.operadora, valorCentavos = prova.valorCentavos,
                pagadorNumero = null, pagadorNome = null, recebidoEm = now,
                estado = EstadoPagamento.PENDENTE, clienteNumero = cliente, grupoId = grupoId,
                prazoAte = now + s.prazoNumeroMs, atualizadoEm = now
            )
            if (pag.inserir(nova) == -1L) return aoReceberComprovativo(prova, cliente, grupoId) // corrida: já existe
            efeitos.responderGrupo(grupoId, cliente, s.msg.aguardaPagamentoGrupo)
            return
        }

        val confere = prova.valorCentavos == ex.valorCentavos
        when (ex.estado) {
            EstadoPagamento.PENDENTE -> {
                val txt = if (ex.clienteNumero == cliente) s.msg.aguardaPagamentoGrupo else s.msg.jaAtendidoGrupo
                efeitos.responderGrupo(grupoId, cliente, txt)
            }
            EstadoPagamento.DISPONIVEL -> {
                if (!confere) return efeitos.responderGrupo(grupoId, cliente, s.msg.naoConfereGrupo)
                pag.ligarCliente(ex.chave, cliente, grupoId, now)
                decidir(ex.chave)
            }
            EstadoPagamento.AGUARDA_NUMERO -> {
                if (!confere) return efeitos.responderGrupo(grupoId, cliente, s.msg.naoConfereGrupo)
                if (ex.clienteNumero == null) {
                    // Estava a ser tratado por SMS; o cliente aparece no grupo → também pede aqui.
                    pag.ligarCliente(ex.chave, cliente, grupoId, now)
                    pag.definirPrazo(ex.chave, now + s.prazoNumeroMs, now)
                    efeitos.responderGrupo(grupoId, cliente, s.msg.pedirNumeroGrupo)
                } else if (ex.clienteNumero == cliente) {
                    efeitos.responderGrupo(grupoId, cliente, s.msg.pedirNumeroGrupo)
                } else {
                    efeitos.responderGrupo(grupoId, cliente, s.msg.jaAtendidoGrupo)
                }
            }
            EstadoPagamento.SEM_DONO -> {
                if (!confere) return efeitos.responderGrupo(grupoId, cliente, s.msg.naoConfereGrupo)
                creditarCarteira(ex, cliente, grupoId, EstadoPagamento.SEM_DONO)
            }
            EstadoPagamento.REVISAO -> efeitos.responderGrupo(grupoId, cliente, s.msg.emAnaliseGrupo)
            else -> efeitos.responderGrupo(grupoId, cliente, s.msg.jaAtendidoGrupo)
        }
    }

    // ───────────── 3. Número de destino (por SMS ou no grupo) ─────────────

    /** SMS recebido de um número qualquer: só interessa se for de um pagador à espera. */
    suspend fun aoReceberSmsDoPagador(remetente: String, texto: String) {
        val n = Phone.normalize(remetente) ?: return
        val p = pag.aguardaPorPagador(n) ?: return
        tratarNumero(p, texto, porSms = true)
    }

    /** Mensagem de um cliente no grupo (ou privado): só interessa se tiver pagamento à espera. */
    suspend fun aoReceberNumeroNoGrupo(cliente: String, texto: String) {
        val p = pag.aguardaPorCliente(cliente) ?: return
        tratarNumero(p, texto, porSms = false)
    }

    private suspend fun tratarNumero(p: PagamentoEntity, texto: String, porSms: Boolean) {
        val s = cfg()
        val now = agora()
        val destino = Regras.extrairNumero(texto)?.let(Phone::normalize)?.takeIf(Phone::isVodacom)

        if (destino == null) {
            pag.contarTentativa(p.chave, now)
            val atual = pag.porChave(p.chave) ?: return
            if (atual.tentativasNumero >= s.maxTentativasNumero) return tempoEsgotado(atual)
            if (porSms) p.pagadorNumero?.let { efeitos.enviarSms(it, render(s.msg.numeroInvalidoSms, s, p)) }
            else p.clienteNumero?.let { efeitos.responderGrupo(p.grupoId, it, s.msg.numeroInvalidoGrupo) }
            return
        }
        val pacote = acharPacote(p.valorCentavos) ?: return
        abrirPedido(p, pacote, destino, EstadoPagamento.AGUARDA_NUMERO, if (porSms) Canal.SMS else Canal.GRUPO)
    }

    // ───────────── 4. Prazos (chamar de 1 em 1 minuto) ─────────────

    suspend fun processarPrazos() {
        val now = agora()
        val s = cfg()

        for (p in pag.comPrazoVencido(listOf(EstadoPagamento.AGUARDA_NUMERO), now)) tempoEsgotado(p)

        for (p in pag.comPrazoVencido(listOf(EstadoPagamento.SEM_DONO, EstadoPagamento.DISPONIVEL), now)) {
            if (pag.mudarEstado(p.chave, p.estado, EstadoPagamento.REVISAO, now) == 1) {
                efeitos.avisarDono(
                    "Pagamento sem dono há muito tempo: ${mt(p.valorCentavos)} MT, ref. ${p.chave}. Precisa de decisão."
                )
            }
        }

        for (p in pag.comPrazoVencido(listOf(EstadoPagamento.PENDENTE), now)) {
            pag.definirPrazo(p.chave, null, now)    // avisa uma única vez; continua à espera do SMS oficial
            p.clienteNumero?.let { efeitos.responderGrupo(p.grupoId, it, s.msg.semPagamentoGrupo) }
        }
        pag.apagarPendentesAntigos(now - 24 * 3_600_000L)
    }

    /**
     * Passaram 10 min (ou 3 tentativas falhadas) sem número.
     * Canal SMS → 2.ª mensagem "só pelo grupo" e o pagamento volta a ficar DISPONIVEL para o grupo.
     * Canal grupo → REVISAO e alerta ao dono.
     */
    private suspend fun tempoEsgotado(p: PagamentoEntity) {
        val s = cfg()
        val now = agora()
        if (p.clienteNumero == null) {
            val n = pag.mudarEstadoComPrazo(
                p.chave, EstadoPagamento.AGUARDA_NUMERO, EstadoPagamento.DISPONIVEL, now + s.prazoReclamacaoMs, now
            )
            if (n == 1 && p.pagadorNumero != null && pag.marcarSmsPrazo(p.chave) == 1) {
                efeitos.enviarSms(p.pagadorNumero, render(s.msg.prazoSms, s, p))
            }
        } else {
            val n = pag.mudarEstado(p.chave, EstadoPagamento.AGUARDA_NUMERO, EstadoPagamento.REVISAO, now)
            if (n == 1) {
                efeitos.responderGrupo(p.grupoId, p.clienteNumero, s.msg.tempoEsgotadoGrupo)
                efeitos.avisarDono("Cliente ${p.clienteNumero} não deu o número a tempo. Pagamento ${mt(p.valorCentavos)} MT, ref. ${p.chave}.")
            }
        }
    }

    // ───────────── Decisão central (pagamento confirmado pelo SMS oficial) ─────────────

    private suspend fun decidir(chave: String) {
        val p = pag.porChave(chave) ?: return
        if (p.estado != EstadoPagamento.DISPONIVEL) return
        val s = cfg()
        val now = agora()
        val pacote = acharPacote(p.valorCentavos)
        val acao = Regras.proximaAcao(pacote?.familia, s.autoAtivar, p.destinoVodacom != null, p.clienteNumero != null)

        when (acao) {
            Acao.PROCESSAR_JA -> {
                val pk = pacote ?: return
                val destino = p.destinoVodacom ?: return
                abrirPedido(p, pk, destino, EstadoPagamento.DISPONIVEL, if (p.clienteNumero != null) Canal.GRUPO else Canal.SMS)
            }
            Acao.PEDIR_NUMERO_SMS -> {
                val n = pag.mudarEstadoComPrazo(chave, EstadoPagamento.DISPONIVEL, EstadoPagamento.AGUARDA_NUMERO, now + s.prazoNumeroMs, now)
                if (n == 0) return
                val para = p.pagadorNumero
                if (para != null && pag.marcarSmsNumero(chave) == 1) {
                    efeitos.enviarSms(para, render(s.msg.pedirNumeroSms, s, p))
                } else if (para == null) {
                    pag.mudarEstado(chave, EstadoPagamento.AGUARDA_NUMERO, EstadoPagamento.REVISAO, now)
                    efeitos.avisarDono("Pagamento ${mt(p.valorCentavos)} MT, ref. $chave, sem número do pagador para pedir o destino.")
                }
            }
            Acao.PEDIR_NUMERO_GRUPO -> {
                val n = pag.mudarEstadoComPrazo(chave, EstadoPagamento.DISPONIVEL, EstadoPagamento.AGUARDA_NUMERO, now + s.prazoNumeroMs, now)
                if (n == 1) p.clienteNumero?.let { efeitos.responderGrupo(p.grupoId, it, s.msg.pedirNumeroGrupo) }
            }
            Acao.AVISAR_DONO -> {
                if (pag.mudarEstado(chave, EstadoPagamento.DISPONIVEL, EstadoPagamento.REVISAO, now) == 0) return
                efeitos.avisarDono(
                    "Pagamento ${mt(p.valorCentavos)} MT (${pacote?.familia}) ref. $chave aguarda ativação manual."
                )
                if (p.clienteNumero != null) efeitos.responderGrupo(p.grupoId, p.clienteNumero, s.msg.recebidoManualGrupo)
                else p.pagadorNumero?.let { efeitos.enviarSms(it, render(s.msg.recebidoManualSms, s, p)) }
            }
            Acao.CREDITAR_CARTEIRA -> {
                val cliente = p.clienteNumero ?: return
                creditarCarteira(p, cliente, p.grupoId, EstadoPagamento.DISPONIVEL)
            }
            Acao.SMS_FORA_TABELA -> {
                val n = pag.mudarEstadoComPrazo(chave, EstadoPagamento.DISPONIVEL, EstadoPagamento.SEM_DONO, now + s.prazoNumeroMs, now)
                if (n == 1 && p.pagadorNumero != null && pag.marcarAvisoSms(chave) == 1) {
                    efeitos.enviarSms(p.pagadorNumero, render(s.msg.foraTabelaSms, s, p, grupoSaldo = true))
                }
            }
        }
    }

    // ───────────── Operações atómicas ─────────────

    /** Reivindica o pagamento (CAS) e cria o pedido na mesma transação. Um pagamento → um pedido. */
    private suspend fun abrirPedido(
        p: PagamentoEntity, pacote: PacoteEntity, destino: String, esperado: EstadoPagamento, canal: Canal
    ) {
        val now = agora()
        db.withTransaction {
            if (pag.mudarEstado(p.chave, esperado, EstadoPagamento.USADO, now) == 0) return@withTransaction
            val id = db.pedidos().inserir(
                PedidoEntity(
                    pagamentoChave = p.chave, clienteNumero = p.clienteNumero ?: p.pagadorNumero, grupoId = p.grupoId, destino = destino,
                    pacoteId = pacote.id, mb = pacote.mb, valorCentavos = p.valorCentavos, canal = canal,
                    estado = EstadoPedido.NA_FILA, criadoEm = now, atualizadoEm = now
                )
            )
            check(id != -1L) { "Pedido duplicado para ${p.chave}" }   // desfaz a transação
            pag.ligarPedido(p.chave, id, now)
        }
    }

    private suspend fun creditarCarteira(p: PagamentoEntity, cliente: String, grupoId: String?, esperado: EstadoPagamento) {
        val s = cfg()
        val now = agora()
        var saldo: Long? = null
        db.withTransaction {
            if (pag.mudarEstado(p.chave, esperado, EstadoPagamento.CARTEIRA, now) == 0) return@withTransaction
            pag.ligarCliente(p.chave, cliente, grupoId, now)
            db.carteira().creditar(cliente, p.valorCentavos, p.chave, now)
            saldo = db.carteira().saldo(cliente)
        }
        saldo?.let { efeitos.responderGrupo(grupoId, cliente, s.msg.saldoGrupo.replace("{SALDO}", mt(it))) }
    }

    private suspend fun acharPacote(valor: Long): PacoteEntity? {
        for (f in ordemFamilias) db.pacotes().porPreco(f, valor)?.let { return it }
        return null
    }

    // ───────────── Util ─────────────

    private fun mt(centavos: Long) = String.format(Locale.ROOT, "%d.%02d", centavos / 100, centavos % 100)

    private fun render(t: String, s: Settings, p: PagamentoEntity, grupoSaldo: Boolean = false): String {
        val frase = if (s.grupo.isBlank()) "" else
            (if (grupoSaldo) s.msg.fraseGrupoSaldo else s.msg.fraseGrupoPedido).replace("{GRUPO}", s.grupo)
        return t.replace("{GRUPO_FRASE}", frase)
            .replace("{VALOR}", mt(p.valorCentavos))
            .replace("{ID}", p.chave.substringAfter(':'))
            .replace("{NEGOCIO}", s.negocio)
            .replace("{GRUPO}", s.grupo)
            .replace(Regex("[ \\t]{2,}"), " ")
            .trim()
    }
}
