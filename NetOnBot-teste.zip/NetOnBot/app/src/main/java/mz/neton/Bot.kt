package mz.neton

import android.telephony.SmsManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import mz.neton.data.LogEntity
import mz.neton.engine.Efeitos
import mz.neton.engine.Executor
import mz.neton.engine.PaymentEngine
import mz.neton.engine.UssdRunner
import mz.neton.payments.PaymentParser
import mz.neton.payments.Phone
import mz.neton.ussd.ResultadoUssd
import mz.neton.ussd.Tarefa
import mz.neton.ussd.UssdBridge

/** Em simulação, tudo o que o bot "diria" fica só no registo. */
class EfeitosReais(private val app: App) : Efeitos {

    override suspend fun enviarSms(para: String, texto: String) {
        if (app.config.simulacao) {
            app.bot.log("SIM", "[SIMULADO] SMS para $para: $texto")
            return
        }
        try {
            val sm = app.getSystemService(SmsManager::class.java)
            sm.sendMultipartTextMessage("+$para", null, sm.divideMessage(texto), null, null)
            app.bot.log("INFO", "SMS enviado para $para: $texto")
        } catch (e: Exception) {
            app.bot.log("ERRO", "Falha ao enviar SMS para $para: ${e.message}")
        }
    }

    // O WhatsApp só existe na Fase 3. Até lá as respostas do grupo ficam no registo.
    override suspend fun responderGrupo(grupoId: String?, cliente: String, texto: String) {
        app.bot.log("GRUPO", "→ $cliente: $texto")
    }

    override suspend fun avisarDono(texto: String) {
        app.bot.log("ALERTA", texto)
        val dono = Phone.normalize(app.config.dono) ?: return
        enviarSms(dono, "ALERTA: $texto")
    }
}

/** USSD de mentira para testar o fluxo todo sem gastar megas. */
object Simulador : UssdRunner {
    override suspend fun executar(tarefa: Tarefa, subId: Int): ResultadoUssd {
        delay(500)
        return when (tarefa) {
            is Tarefa.Transferir -> ResultadoUssd.Sucesso(tarefa.mb, tarefa.destino, 100_000)
            is Tarefa.ConsultarSaldo -> ResultadoUssd.Saldo(100_000)
        }
    }
}

class Bot(private val app: App) {

    private val efeitos = EfeitosReais(app)

    val engine = PaymentEngine(app.db, efeitos, { app.config.settings() })

    private val runner = object : UssdRunner {
        override suspend fun executar(tarefa: Tarefa, subId: Int): ResultadoUssd =
            if (app.config.simulacao) Simulador.executar(tarefa, subId)
            else UssdBridge.executar(app, tarefa, subId, app.config.formato())
    }

    val executor = Executor(app.db, runner, efeitos, { app.config.execSettings() })

    private fun parser() = PaymentParser(app.config.listaRemetentes())

    /** SMS recebido: pagamento oficial, ou resposta de um pagador com o número de destino. */
    suspend fun aoReceberSms(remetente: String?, corpo: String) {
        if (!app.config.botLigado) {
            log("INFO", "Bot desligado: SMS de $remetente ignorado.")
            return
        }
        val p = parser()
        val oficiais = p.parseOfficialSms(remetente, corpo)
        when {
            oficiais.isNotEmpty() -> oficiais.forEach {
                log("INFO", "Pagamento ${it.chave}: ${it.valorCentavos / 100}.${"%02d".format(it.valorCentavos % 100)} MT de ${it.contraparte}")
                engine.aoReceberSmsOficial(it)
            }
            remetente != null && !p.isOfficialSender(remetente) -> engine.aoReceberSmsDoPagador(remetente, corpo)
        }
    }

    /** Mensagem de um cliente no grupo (por agora simulada na aba Testar). */
    suspend fun simularGrupo(clienteRaw: String, texto: String) {
        if (!app.config.botLigado) {
            log("INFO", "Bot desligado: mensagem do grupo ignorada.")
            return
        }
        val cliente = Phone.normalize(clienteRaw)
        if (cliente == null) {
            log("ERRO", "Número de cliente inválido: $clienteRaw")
            return
        }
        val provas = parser().parseProof(texto)
        if (provas.isNotEmpty()) provas.forEach { engine.aoReceberComprovativo(it, cliente, "grupo-teste") }
        else engine.aoReceberNumeroNoGrupo(cliente, texto)
    }

    /** Corre a fila em segundo plano (o USSD demora). Só uma execução de cada vez. */
    fun acordarFila() {
        app.scope.launch {
            try { executor.processarFila() } catch (e: Exception) { log("ERRO", "Fila: ${e.message}") }
        }
    }

    /** Chamado a cada 15 s pelo serviço. */
    suspend fun ciclo() {
        if (!app.config.botLigado) return
        engine.processarPrazos()
        executor.processarFila()
    }

    suspend fun log(nivel: String, msg: String) {
        app.db.logs().inserir(LogEntity(nivel = nivel, origem = "bot", mensagem = msg.take(2000), criadoEm = System.currentTimeMillis()))
    }
}
