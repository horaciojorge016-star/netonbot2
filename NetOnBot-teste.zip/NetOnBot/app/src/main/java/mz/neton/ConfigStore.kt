package mz.neton

import android.content.Context
import mz.neton.engine.ExecSettings
import mz.neton.engine.Settings
import mz.neton.ussd.FormatoDestino

class ConfigStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("config", Context.MODE_PRIVATE)

    var botLigado: Boolean
        get() = sp.getBoolean("botLigado", false)
        set(v) = sp.edit().putBoolean("botLigado", v).apply()

    /** Simulação: não marca USSD e não envia SMS reais (só regista no log). Ligada por omissão. */
    var simulacao: Boolean
        get() = sp.getBoolean("simulacao", true)
        set(v) = sp.edit().putBoolean("simulacao", v).apply()

    var negocio: String
        get() = sp.getString("negocio", "") ?: ""
        set(v) = sp.edit().putString("negocio", v).apply()

    var grupo: String
        get() = sp.getString("grupo", "") ?: ""
        set(v) = sp.edit().putString("grupo", v).apply()

    var dono: String
        get() = sp.getString("dono", "") ?: ""
        set(v) = sp.edit().putString("dono", v).apply()

    var custoGbCentavos: Long
        get() = sp.getLong("custoGb", 0L)
        set(v) = sp.edit().putLong("custoGb", v).apply()

    var remetentes: String
        get() = sp.getString("remetentes", "M-Pesa,eMola") ?: "M-Pesa,eMola"
        set(v) = sp.edit().putString("remetentes", v).apply()

    /** true = envia o destino com 9 dígitos; false = com 258. */
    var destino9: Boolean
        get() = sp.getBoolean("destino9", true)
        set(v) = sp.edit().putBoolean("destino9", v).apply()

    fun listaRemetentes(): Set<String> =
        remetentes.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    fun settings() = Settings(negocio = negocio, grupo = grupo)
    fun execSettings() = ExecSettings(negocio = negocio, custoPorGbCentavos = custoGbCentavos)
    fun formato() = if (destino9) FormatoDestino.NOVE_DIGITOS else FormatoDestino.COM_258
}
