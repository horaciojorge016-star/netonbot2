package mz.neton.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import mz.neton.payments.Operadora
import java.time.Instant
import java.time.ZoneId

class Converters {
    @TypeConverter fun operadoraToString(v: Operadora): String = v.name
    @TypeConverter fun stringToOperadora(v: String): Operadora = Operadora.valueOf(v)

    @TypeConverter fun estadoPagToString(v: EstadoPagamento): String = v.name
    @TypeConverter fun stringToEstadoPag(v: String): EstadoPagamento = EstadoPagamento.valueOf(v)

    @TypeConverter fun estadoPedToString(v: EstadoPedido): String = v.name
    @TypeConverter fun stringToEstadoPed(v: String): EstadoPedido = EstadoPedido.valueOf(v)

    @TypeConverter fun canalToString(v: Canal): String = v.name
    @TypeConverter fun stringToCanal(v: String): Canal = Canal.valueOf(v)

    @TypeConverter fun familiaToString(v: Familia): String = v.name
    @TypeConverter fun stringToFamilia(v: String): Familia = Familia.valueOf(v)

    @TypeConverter fun tipoMovToString(v: TipoMov): String = v.name
    @TypeConverter fun stringToTipoMov(v: String): TipoMov = TipoMov.valueOf(v)
}

@Database(
    entities = [
        ConfigEntity::class, PacoteEntity::class, ClienteEntity::class, PagamentoEntity::class,
        PedidoEntity::class, CarteiraMovimento::class, SimEntity::class, LogEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun pagamentos(): PagamentoDao
    abstract fun pedidos(): PedidoDao
    abstract fun carteira(): CarteiraDao
    abstract fun sims(): SimDao
    abstract fun config(): ConfigDao
    abstract fun pacotes(): PacoteDao
    abstract fun logs(): LogDao

    companion object {
        @Volatile private var instancia: AppDatabase? = null

        fun get(context: Context): AppDatabase = instancia ?: synchronized(this) {
            instancia ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "neton.db")
                .build().also { instancia = it }
        }

        /** Para testes: base em memória. */
        fun emMemoria(context: Context): AppDatabase =
            Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).build()
    }
}

object Dia {
    private val ZONE = ZoneId.of("Africa/Maputo")

    /** "2026-10-31" no fuso de Maputo. O limite diário dos SIMs reinicia à 00:00 daqui. */
    fun hoje(agoraMs: Long = System.currentTimeMillis()): String =
        Instant.ofEpochMilli(agoraMs).atZone(ZONE).toLocalDate().toString()
}
