package mz.neton.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import mz.neton.payments.Operadora

// ───────────── Enums ─────────────

enum class EstadoPagamento {
    DISPONIVEL,      // SMS oficial recebido, ainda sem dono
    AGUARDA_NUMERO,  // à espera do número de destino (prazo 10 min)
    USADO,           // reivindicado por um pedido
    CONCLUIDO,       // megas entregues
    CARTEIRA,        // valor fora da tabela, creditado na carteira
    SEM_DONO,        // fora da tabela, sem comprovativo no grupo
    PENDENTE,        // comprovativo chegou antes do SMS oficial
    FALHOU,
    REVISAO          // precisa de decisão do dono
}

enum class EstadoPedido { NA_FILA, EM_EXECUCAO, CONCLUIDO, FALHOU, REVISAO }

enum class Canal { SMS, GRUPO, CARTEIRA, MANUAL, PARCEIRO, AGENDADO }

enum class Familia { DIARIO, PROMOCAO, SEMANAL, MENSAL, DIAMANTE }

/** CREDITO(+), AJUSTE_ADMIN(±), RESERVA(−), ESTORNO(+, anula uma reserva). */
enum class TipoMov { CREDITO, AJUSTE_ADMIN, RESERVA, ESTORNO }

enum class ResultadoMov { OK, SALDO_INSUFICIENTE, DUPLICADO, NAO_ENCONTRADO }

// ───────────── Entidades ─────────────

@Entity(tableName = "config")
data class ConfigEntity(@PrimaryKey val chave: String, val valor: String)

@Entity(tableName = "pacote", indices = [Index(value = ["familia", "precoCentavos"], unique = true)])
data class PacoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val familia: Familia,
    val precoCentavos: Long,
    val mb: Int,
    val duracaoDias: Int? = null,
    val extras: String? = null,
    val ativo: Boolean = true
)

@Entity(tableName = "cliente")
data class ClienteEntity(
    @PrimaryKey val numero: String,          // WhatsApp, formato 258XXXXXXXXX
    val nome: String? = null,
    val pontos: Int = 0,
    val revendedor: Boolean = false,
    val criadoEm: Long
)

@Entity(
    tableName = "pagamento",
    indices = [Index(value = ["chave"], unique = true), Index("estado")]
)
data class PagamentoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chave: String,                        // operadora:ID  (único)
    val operadora: Operadora,
    val valorCentavos: Long,
    val pagadorNumero: String?,
    val pagadorNome: String?,
    val destinoVodacom: String? = null,       // do campo Conteudo (e-Mola)
    val conteudoBruto: String? = null,
    val smsEm: Long? = null,                  // hora do SMS oficial
    val recebidoEm: Long,
    val estado: EstadoPagamento,
    val clienteNumero: String? = null,        // WhatsApp, preenchido quando cola comprovativo
    val grupoId: String? = null,
    val pedidoId: Long? = null,
    val tentativasNumero: Int = 0,            // máx. 3
    val avisoSmsEnviado: Boolean = false,     // SMS "fora da tabela" só 1 vez
    val smsNumeroEnviado: Boolean = false,    // SMS "indique o número" só 1 vez
    val smsPrazoEnviado: Boolean = false,     // SMS "não recebemos a tempo" só 1 vez
    val prazoAte: Long? = null,               // 10 min
    val atualizadoEm: Long
)

@Entity(
    tableName = "pedido",
    // Um pagamento só pode gerar UM pedido (NULL permitido várias vezes: carteira/manual).
    indices = [Index(value = ["pagamentoChave"], unique = true), Index("estado")]
)
data class PedidoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pagamentoChave: String?,
    val clienteNumero: String?,
    val grupoId: String? = null,              // onde responder (canal grupo/carteira)
    val destino: String,                      // 258XXXXXXXXX (Vodacom)
    val pacoteId: Long?,
    val mb: Int,
    val valorCentavos: Long,
    val canal: Canal,
    val estado: EstadoPedido,
    val simSubId: Int? = null,
    val agenteId: String? = null,
    val tentativas: Int = 0,
    val custoCentavos: Long = 0,
    val lucroCentavos: Long = 0,
    val semPagamento: Boolean = false,        // oferta/bónus/.enviar
    val mensagemEcra: String? = null,
    val criadoEm: Long,
    val atualizadoEm: Long
)

/** Registo imutável. Saldo = soma de valorCentavos. Nunca se edita nem se apaga. */
@Entity(
    tableName = "carteira_movimento",
    indices = [Index(value = ["chaveIdem"], unique = true), Index("clienteNumero")]
)
data class CarteiraMovimento(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clienteNumero: String,
    val tipo: TipoMov,
    val valorCentavos: Long,                  // com sinal
    val chaveIdem: String,                    // garante que o mesmo evento não entra duas vezes
    val pagamentoChave: String? = null,
    val pedidoId: Long? = null,
    val autor: String? = null,                // quem fez o ajuste admin
    val motivo: String? = null,
    val criadoEm: Long
)

@Entity(tableName = "sim")
data class SimEntity(
    @PrimaryKey val subId: Int,
    val operadora: String,
    val numero: String?,
    val usosHoje: Int = 0,
    val diaUso: String = "",                  // yyyy-MM-dd (Maputo); reset à 00:00
    val limiteDiario: Int = 10,
    val saldoMb: Int? = null,
    val ativo: Boolean = true
)

@Entity(tableName = "log", indices = [Index("criadoEm")])
data class LogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nivel: String,
    val origem: String,
    val mensagem: String,
    val criadoEm: Long
)
