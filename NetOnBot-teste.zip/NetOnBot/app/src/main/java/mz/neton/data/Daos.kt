package mz.neton.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import java.util.UUID

@Dao
abstract class PagamentoDao {

    @Query("SELECT * FROM pagamento ORDER BY id DESC LIMIT :n")
    abstract suspend fun ultimos(n: Int): List<PagamentoEntity>

    /** Devolve -1 se a chave (operadora:ID) já existe → pagamento duplicado, nada é gravado. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun inserir(p: PagamentoEntity): Long

    @Query("SELECT * FROM pagamento WHERE chave = :chave")
    abstract suspend fun porChave(chave: String): PagamentoEntity?

    /**
     * Compare-and-set: só muda se o estado atual for o esperado.
     * Devolve 1 se conseguiu, 0 se outro canal chegou primeiro.
     * É assim que SMS e grupo "disputam" o mesmo pagamento sem duplicar.
     */
    @Query("UPDATE pagamento SET estado = :novo, atualizadoEm = :agora WHERE chave = :chave AND estado = :esperado")
    abstract suspend fun mudarEstado(chave: String, esperado: EstadoPagamento, novo: EstadoPagamento, agora: Long): Int

    @Query("UPDATE pagamento SET clienteNumero = :cliente, grupoId = :grupo, atualizadoEm = :agora WHERE chave = :chave")
    abstract suspend fun ligarCliente(chave: String, cliente: String, grupo: String?, agora: Long): Int

    @Query("UPDATE pagamento SET pedidoId = :pedidoId, atualizadoEm = :agora WHERE chave = :chave")
    abstract suspend fun ligarPedido(chave: String, pedidoId: Long, agora: Long): Int

    @Query("UPDATE pagamento SET prazoAte = :prazo, atualizadoEm = :agora WHERE chave = :chave")
    abstract suspend fun definirPrazo(chave: String, prazo: Long?, agora: Long): Int

    @Query("UPDATE pagamento SET tentativasNumero = tentativasNumero + 1, atualizadoEm = :agora WHERE chave = :chave")
    abstract suspend fun contarTentativa(chave: String, agora: Long): Int

    @Query("UPDATE pagamento SET avisoSmsEnviado = 1 WHERE chave = :chave AND avisoSmsEnviado = 0")
    abstract suspend fun marcarAvisoSms(chave: String): Int   // 1 = pode enviar; 0 = já foi enviado

    @Query("UPDATE pagamento SET estado = :novo, prazoAte = :prazo, atualizadoEm = :agora WHERE chave = :chave AND estado = :esperado")
    abstract suspend fun mudarEstadoComPrazo(chave: String, esperado: EstadoPagamento, novo: EstadoPagamento, prazo: Long?, agora: Long): Int

    /** O SMS oficial chegou depois do comprovativo: os dados OFICIAIS substituem os do comprovativo. */
    @Query("UPDATE pagamento SET valorCentavos = :valor, pagadorNumero = :pagador, pagadorNome = :nome, destinoVodacom = :destino, conteudoBruto = :conteudo, smsEm = :smsEm, estado = 'DISPONIVEL', prazoAte = NULL, atualizadoEm = :agora WHERE chave = :chave AND estado = 'PENDENTE'")
    abstract suspend fun confirmarPendente(chave: String, valor: Long, pagador: String?, nome: String?, destino: String?, conteudo: String?, smsEm: Long?, agora: Long): Int

    @Query("UPDATE pagamento SET clienteNumero = NULL, grupoId = NULL, atualizadoEm = :agora WHERE chave = :chave")
    abstract suspend fun limparCliente(chave: String, agora: Long): Int

    @Query("UPDATE pagamento SET smsNumeroEnviado = 1 WHERE chave = :chave AND smsNumeroEnviado = 0")
    abstract suspend fun marcarSmsNumero(chave: String): Int

    @Query("UPDATE pagamento SET smsPrazoEnviado = 1 WHERE chave = :chave AND smsPrazoEnviado = 0")
    abstract suspend fun marcarSmsPrazo(chave: String): Int

    @Query("SELECT * FROM pagamento WHERE estado = 'AGUARDA_NUMERO' AND pagadorNumero = :numero ORDER BY recebidoEm ASC LIMIT 1")
    abstract suspend fun aguardaPorPagador(numero: String): PagamentoEntity?

    @Query("SELECT * FROM pagamento WHERE estado = 'AGUARDA_NUMERO' AND clienteNumero = :numero ORDER BY recebidoEm ASC LIMIT 1")
    abstract suspend fun aguardaPorCliente(numero: String): PagamentoEntity?

    @Query("DELETE FROM pagamento WHERE estado = 'PENDENTE' AND recebidoEm < :antes")
    abstract suspend fun apagarPendentesAntigos(antes: Long): Int

    @Query("SELECT * FROM pagamento WHERE estado IN (:estados) AND prazoAte IS NOT NULL AND prazoAte < :agora")
    abstract suspend fun comPrazoVencido(estados: List<EstadoPagamento>, agora: Long): List<PagamentoEntity>

    @Query("SELECT * FROM pagamento WHERE estado = :estado ORDER BY recebidoEm ASC")
    abstract suspend fun porEstado(estado: EstadoPagamento): List<PagamentoEntity>
}

@Dao
abstract class PedidoDao {

    @Query("SELECT * FROM pedido ORDER BY id DESC LIMIT :n")
    abstract suspend fun ultimos(n: Int): List<PedidoEntity>

    /** Falha (-1) se já existe pedido para esse pagamento. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun inserir(p: PedidoEntity): Long

    @Query("SELECT * FROM pedido WHERE id = :id")
    abstract suspend fun porId(id: Long): PedidoEntity?

    @Query("UPDATE pedido SET estado = :novo, atualizadoEm = :agora WHERE id = :id AND estado = :esperado")
    abstract suspend fun mudarEstado(id: Long, esperado: EstadoPedido, novo: EstadoPedido, agora: Long): Int

    @Query("UPDATE pedido SET simSubId = :sim, agenteId = :agente, tentativas = tentativas + 1, atualizadoEm = :agora WHERE id = :id")
    abstract suspend fun registarTentativa(id: Long, sim: Int?, agente: String?, agora: Long): Int

    @Query("UPDATE pedido SET mensagemEcra = :msg, custoCentavos = :custo, lucroCentavos = :lucro, atualizadoEm = :agora WHERE id = :id")
    abstract suspend fun registarResultado(id: Long, msg: String?, custo: Long, lucro: Long, agora: Long): Int

    @Query("SELECT * FROM pedido WHERE estado = :estado ORDER BY criadoEm ASC")
    abstract suspend fun porEstado(estado: EstadoPedido): List<PedidoEntity>
}

@Dao
abstract class CarteiraDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun inserirMov(m: CarteiraMovimento): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun garantirCliente(c: ClienteEntity): Long

    @Query("SELECT COALESCE(SUM(valorCentavos), 0) FROM carteira_movimento WHERE clienteNumero = :numero")
    abstract suspend fun saldo(numero: String): Long

    @Query("SELECT * FROM carteira_movimento WHERE clienteNumero = :numero ORDER BY id DESC LIMIT :limite")
    abstract suspend fun ultimos(numero: String, limite: Int): List<CarteiraMovimento>

    @Query("SELECT * FROM carteira_movimento WHERE chaveIdem = :idem LIMIT 1")
    abstract suspend fun porIdem(idem: String): CarteiraMovimento?

    /** Depósito vindo de um pagamento fora da tabela. Um pagamento só credita uma vez. */
    @Transaction
    open suspend fun creditar(cliente: String, valorCentavos: Long, pagamentoChave: String, agora: Long): ResultadoMov {
        require(valorCentavos > 0)
        garantirCliente(ClienteEntity(numero = cliente, criadoEm = agora))
        val id = inserirMov(
            CarteiraMovimento(
                clienteNumero = cliente, tipo = TipoMov.CREDITO, valorCentavos = valorCentavos,
                chaveIdem = "credito:$pagamentoChave", pagamentoChave = pagamentoChave, criadoEm = agora
            )
        )
        return if (id == -1L) ResultadoMov.DUPLICADO else ResultadoMov.OK
    }

    /** Reserva o valor ANTES do USSD. Verificação e gravação na mesma transação. */
    @Transaction
    open suspend fun reservar(cliente: String, valorCentavos: Long, pedidoId: Long, agora: Long): ResultadoMov {
        require(valorCentavos > 0)
        val idem = "reserva:$pedidoId"
        if (porIdem(idem) != null) return ResultadoMov.DUPLICADO
        if (saldo(cliente) < valorCentavos) return ResultadoMov.SALDO_INSUFICIENTE
        inserirMov(
            CarteiraMovimento(
                clienteNumero = cliente, tipo = TipoMov.RESERVA, valorCentavos = -valorCentavos,
                chaveIdem = idem, pedidoId = pedidoId, criadoEm = agora
            )
        )
        return ResultadoMov.OK
    }

    /** Falha confirmada: devolve a reserva. Só uma vez por pedido. */
    @Transaction
    open suspend fun estornar(pedidoId: Long, agora: Long): ResultadoMov {
        val reserva = porIdem("reserva:$pedidoId") ?: return ResultadoMov.NAO_ENCONTRADO
        val id = inserirMov(
            CarteiraMovimento(
                clienteNumero = reserva.clienteNumero, tipo = TipoMov.ESTORNO, valorCentavos = -reserva.valorCentavos,
                chaveIdem = "estorno:$pedidoId", pedidoId = pedidoId, criadoEm = agora
            )
        )
        return if (id == -1L) ResultadoMov.DUPLICADO else ResultadoMov.OK
    }

    /** Comandos .saldo +valor / .saldo -valor. Nunca deixa o saldo negativo. */
    @Transaction
    open suspend fun ajusteAdmin(
        cliente: String, deltaCentavos: Long, autor: String, motivo: String?, agora: Long
    ): ResultadoMov {
        require(deltaCentavos != 0L)
        garantirCliente(ClienteEntity(numero = cliente, criadoEm = agora))
        if (deltaCentavos < 0 && saldo(cliente) + deltaCentavos < 0) return ResultadoMov.SALDO_INSUFICIENTE
        inserirMov(
            CarteiraMovimento(
                clienteNumero = cliente, tipo = TipoMov.AJUSTE_ADMIN, valorCentavos = deltaCentavos,
                chaveIdem = "ajuste:${UUID.randomUUID()}", autor = autor, motivo = motivo, criadoEm = agora
            )
        )
        return ResultadoMov.OK
    }
}

@Dao
abstract class SimDao {

    @Query("SELECT * FROM sim ORDER BY subId")
    abstract suspend fun todos(): List<SimEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun inserirSeNovo(s: SimEntity): Long

    @Query("UPDATE sim SET ativo = :ativo WHERE subId = :subId")
    abstract suspend fun definirAtivo(subId: Int, ativo: Boolean): Int

    @Query("UPDATE sim SET operadora = :op WHERE subId = :subId")
    abstract suspend fun definirOperadora(subId: Int, op: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun guardar(s: SimEntity)

    @Query("SELECT * FROM sim WHERE ativo = 1 ORDER BY usosHoje ASC")
    abstract suspend fun ativos(): List<SimEntity>

    @Query("UPDATE sim SET usosHoje = 0, diaUso = :hoje WHERE subId = :subId AND diaUso <> :hoje")
    abstract suspend fun resetarSeNovoDia(subId: Int, hoje: String): Int

    @Query("UPDATE sim SET usosHoje = usosHoje + 1 WHERE subId = :subId AND ativo = 1 AND usosHoje < limiteDiario")
    abstract suspend fun consumirQuota(subId: Int): Int

    /** true = quota reservada. `hoje` = yyyy-MM-dd no fuso de Maputo. */
    @Transaction
    open suspend fun reservarQuota(subId: Int, hoje: String): Boolean {
        resetarSeNovoDia(subId, hoje)
        return consumirQuota(subId) == 1
    }

    /** Falha confirmada: devolve a quota. */
    @Query("UPDATE sim SET usosHoje = CASE WHEN usosHoje > 0 THEN usosHoje - 1 ELSE 0 END WHERE subId = :subId")
    abstract suspend fun devolverQuota(subId: Int): Int

    @Query("UPDATE sim SET saldoMb = :mb WHERE subId = :subId")
    abstract suspend fun atualizarSaldo(subId: Int, mb: Int): Int
}

@Dao
abstract class ConfigDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun guardar(c: ConfigEntity)

    @Query("SELECT valor FROM config WHERE chave = :chave")
    abstract suspend fun obter(chave: String): String?
}

@Dao
abstract class PacoteDao {

    @Query("SELECT * FROM pacote ORDER BY familia, precoCentavos")
    abstract suspend fun todos(): List<PacoteEntity>

    @Query("DELETE FROM pacote WHERE id = :id")
    abstract suspend fun apagar(id: Long): Int
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun guardar(p: PacoteEntity): Long

    @Query("SELECT * FROM pacote WHERE id = :id")
    abstract suspend fun porId(id: Long): PacoteEntity?

    /** Preço exato de um diário. Null = fora da tabela → carteira. */
    @Query("SELECT * FROM pacote WHERE familia = :familia AND precoCentavos = :preco AND ativo = 1 LIMIT 1")
    abstract suspend fun porPreco(familia: Familia, preco: Long): PacoteEntity?

    @Query("SELECT * FROM pacote WHERE ativo = 1 AND precoCentavos = :preco ORDER BY familia LIMIT 1")
    abstract suspend fun qualquerPorPreco(preco: Long): PacoteEntity?

    @Query("SELECT * FROM pacote WHERE familia = :familia AND ativo = 1 ORDER BY precoCentavos")
    abstract suspend fun porFamilia(familia: Familia): List<PacoteEntity>
}

@Dao
abstract class LogDao {

    @Query("SELECT * FROM log ORDER BY id DESC LIMIT :n")
    abstract suspend fun ultimos(n: Int): List<LogEntity>
    @Insert
    abstract suspend fun inserir(l: LogEntity): Long

    @Query("DELETE FROM log WHERE criadoEm < :antes")
    abstract suspend fun limparAntes(antes: Long): Int
}
