package mz.neton.payments

import java.time.LocalDateTime
import java.time.ZoneId

enum class Operadora(val codigo: String) { MPESA("mpesa"), EMOLA("emola") }

/** SMS_OFICIAL = confirma que o dinheiro entrou. COMPROVATIVO = só liga o pagamento ao cliente. */
enum class Origem { SMS_OFICIAL, COMPROVATIVO }

data class ParsedPayment(
    val operadora: Operadora,
    val origem: Origem,
    val id: String,
    val valorCentavos: Long,
    /** SMS oficial: número de quem pagou. Comprovativo: número de quem recebeu (o negócio). Formato 258XXXXXXXXX. */
    val contraparte: String?,
    val nome: String?,
    /** Número Vodacom válido vindo do campo "Conteudo" (e-Mola). Null se vazio ou inválido. */
    val destinoVodacom: String?,
    val conteudoBruto: String?,
    val timestampMs: Long?
) {
    /** Chave única anti-duplicação: operadora + ID. */
    val chave: String get() = "${operadora.codigo}:$id"
}

object Phone {
    /** Aceita 9 dígitos, 258+9 dígitos ou +258...; devolve 258XXXXXXXXX ou null. */
    fun normalize(raw: String?): String? {
        val d = raw?.filter { it.isDigit() } ?: return null
        return when {
            d.length == 9 -> "258$d"
            d.length == 12 && d.startsWith("258") -> d
            else -> null
        }
    }

    /** Vodacom = 84 ou 85. */
    fun isVodacom(normalized: String?): Boolean =
        normalized != null && normalized.length == 12 && normalized.startsWith("258") &&
            normalized.substring(3, 5) in setOf("84", "85")
}

object Money {
    /** "23.00" -> 2300. Aceita separador de milhares ("1,500.00"). Sem Double. */
    fun parseCentavos(raw: String): Long? {
        val parts = raw.replace(",", "").trim().split(".")
        if (parts.size > 2) return null
        val whole = parts[0].toLongOrNull() ?: return null
        if (parts.size == 1) return whole * 100
        val frac = parts[1].padEnd(2, '0').take(2).toLongOrNull() ?: return null
        return whole * 100 + frac
    }
}

object TimeParser {
    private val ZONE = ZoneId.of("Africa/Maputo")
    private val DATE = Regex("""(\d{1,2})/(\d{1,2})/(\d{2,4})""")
    private val TIME = Regex("""(?i)(\d{1,2}):(\d{2})(?::(\d{2}))?\s*([AP]M)?""")

    /** Aceita "31/10/2026" ou "31/10/26"; "16:20:06" (24h) ou "7:25 PM" (12h). */
    fun parse(date: String, time: String): Long? = try {
        val d = DATE.find(date) ?: return null
        val t = TIME.find(time) ?: return null
        var year = d.groupValues[3].toInt()
        if (year < 100) year += 2000
        var hour = t.groupValues[1].toInt()
        val ampm = t.groupValues[4].uppercase()
        if (ampm == "PM" && hour < 12) hour += 12
        if (ampm == "AM" && hour == 12) hour = 0
        val sec = t.groupValues[3].ifEmpty { "0" }.toInt()
        LocalDateTime.of(year, d.groupValues[2].toInt(), d.groupValues[1].toInt(), hour, t.groupValues[2].toInt(), sec)
            .atZone(ZONE).toInstant().toEpochMilli()
    } catch (e: Exception) {
        null
    }
}

class PaymentParser(allowedSenders: Set<String> = setOf("M-Pesa", "eMola")) {

    private val allowed = allowedSenders.map { normSender(it) }.toSet()

    private fun normSender(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    fun isOfficialSender(sender: String?): Boolean =
        sender != null && normSender(sender) in allowed

    /** SMS recebido no aparelho Central. Só aceita remetentes oficiais e só "Recebeu/Recebeste". */
    fun parseOfficialSms(sender: String?, body: String): List<ParsedPayment> {
        if (!isOfficialSender(sender)) return emptyList()
        val out = mutableListOf<ParsedPayment>()

        for (m in EMOLA_RECEBIDO.findAll(body)) {
            val g = m.groupValues
            val conteudo = g[7].trim()
            val dest = Phone.normalize(conteudo).takeIf { Phone.isVodacom(it) }
            build(Operadora.EMOLA, Origem.SMS_OFICIAL, g[1], g[2], g[3], g[4], g[6], g[5], dest, conteudo)?.let(out::add)
        }
        for (m in MPESA_RECEBIDO.findAll(body)) {
            val g = m.groupValues
            build(Operadora.MPESA, Origem.SMS_OFICIAL, g[1], g[2], g[3], g[4], g[5], g[6], null, null)?.let(out::add)
        }
        return out.distinctBy { it.chave }
    }

    /** Texto colado no grupo (pode trazer vários SMS juntos). Nunca confirma pagamento sozinho. */
    fun parseProof(text: String): List<ParsedPayment> {
        val out = mutableListOf<ParsedPayment>()

        val emola = EMOLA_COMPROVATIVO.findAll(text).toList()
        for ((i, m) in emola.withIndex()) {
            val g = m.groupValues
            val end = emola.getOrNull(i + 1)?.range?.first ?: text.length
            val segmento = text.substring(m.range.last + 1, end)
            val conteudo = CONTEUDO.find(segmento)?.groupValues?.get(1)?.trim()
            val dest = Phone.normalize(conteudo).takeIf { Phone.isVodacom(it) }
            build(Operadora.EMOLA, Origem.COMPROVATIVO, g[1], g[2], g[3], g[4], g[6], g[5], dest, conteudo)?.let(out::add)
        }
        for (m in MPESA_COMPROVATIVO.findAll(text)) {
            val g = m.groupValues
            build(Operadora.MPESA, Origem.COMPROVATIVO, g[1], g[2], g[3], g[4], g[5], g[6], null, null)?.let(out::add)
        }
        return out.distinctBy { it.chave }
    }

    private fun build(
        op: Operadora, origem: Origem, id: String, valor: String, numero: String, nome: String,
        data: String, hora: String, dest: String?, conteudo: String?
    ): ParsedPayment? {
        val centavos = Money.parseCentavos(valor) ?: return null
        if (centavos <= 0) return null
        return ParsedPayment(
            operadora = op,
            origem = origem,
            id = id.uppercase(),
            valorCentavos = centavos,
            contraparte = Phone.normalize(numero),
            nome = nome.trim(),
            destinoVodacom = dest,
            conteudoBruto = conteudo,
            timestampMs = TimeParser.parse(data, hora)
        )
    }

    companion object {
        // Grupos EMOLA_RECEBIDO: 1 id, 2 valor, 3 numero, 4 nome, 5 hora, 6 data, 7 conteudo
        private val EMOLA_RECEBIDO = Regex("""(?i)ID Trans:\s*(PP\d{6}\.\d{4}\.[A-Z0-9]+)\.\s*Recebeu\s+([\d,]+(?:\.\d{1,2})?)\s*MT\s+de\s+(\d{9,12})\s*,\s*(.+?)\s+as\s+(\d{1,2}:\d{2}:\d{2})\s+(\d{1,2}/\d{1,2}/\d{2,4})\.\s*Conte[uú]do:\s*([^.]*?)\s*\.""")

        // Grupos MPESA_RECEBIDO: 1 id, 2 valor, 3 numero, 4 nome, 5 data, 6 hora
        private val MPESA_RECEBIDO = Regex("""(?i)Confirmado\s+([A-Z0-9]{8,12})\.\s*Recebeste\s+([\d,]+(?:\.\d{1,2})?)\s*MT\s+de\s+(\d{9,12})\s*-\s*(.+?)\s+aos\s+(\d{1,2}/\d{1,2}/\d{2,4})\s+as\s+(\d{1,2}:\d{2}\s*[AP]M)""")

        // Grupos EMOLA_COMPROVATIVO: 1 id, 2 valor, 3 numero, 4 nome, 5 hora, 6 data
        private val EMOLA_COMPROVATIVO = Regex("""(?i)ID da transa[cç][aã]o\s+(PP\d{6}\.\d{4}\.[A-Z0-9]+)\.\s*Transferiste\s+([\d,]+(?:\.\d{1,2})?)\s*MT\s+para conta\s+(\d{9,12})\s*,\s*nome:\s*(.+?)\s+as\s+(\d{1,2}:\d{2}:\d{2})\s+de\s+(\d{1,2}/\d{1,2}/\d{2,4})\.""")

        // Grupos MPESA_COMPROVATIVO: 1 id, 2 valor, 3 numero, 4 nome, 5 data, 6 hora
        private val MPESA_COMPROVATIVO = Regex("""(?i)Confirmado\s+([A-Z0-9]{8,12})\.\s*Transferiste\s+([\d,]+(?:\.\d{1,2})?)\s*MT\s+e a taxa foi de\s+[\d,.]+\s*MT\s+para\s+(\d{9,12})\s*-\s*(.+?)\s+aos\s+(\d{1,2}/\d{1,2}/\d{2,4})\s+as\s+(\d{1,2}:\d{2}\s*[AP]M)""")

        private val CONTEUDO = Regex("""(?i)Conte[uú]do:\s*([^.]*?)\s*\.""")
    }
}
