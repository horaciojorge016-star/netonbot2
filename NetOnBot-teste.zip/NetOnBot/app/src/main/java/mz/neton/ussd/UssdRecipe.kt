package mz.neton.ussd

import java.text.Normalizer
import java.util.Locale

// ───────────── Tipos ─────────────

enum class TipoEcra { MENU_PRINCIPAL, MENU_INTERNET, PEDE_QUANTIDADE, PEDE_DESTINO, SUCESSO, ERRO_MINIMO, DESCONHECIDO }

data class Ecra(
    val tipo: TipoEcra,
    val saldoMb: Int? = null,          // PEDE_QUANTIDADE: "Saldo de dados: 580 MB"
    val mbTransferidos: Int? = null,   // SUCESSO
    val numero: String? = null         // SUCESSO: 258XXXXXXXXX
)

sealed class Tarefa {
    /** destino no formato 258XXXXXXXXX. MB entre 100 e 10240. */
    data class Transferir(val mb: Int, val destino: String) : Tarefa() {
        init {
            require(mb in MIN_MB..MAX_MB) { "MB fora do limite ($MIN_MB..$MAX_MB): $mb" }
            require(destino.length == 12 && destino.startsWith("258") && destino.all { it.isDigit() }) { "Destino inválido: $destino" }
        }
    }
    object ConsultarSaldo : Tarefa()

    companion object {
        const val MIN_MB = 100
        const val MAX_MB = 10240
    }
}

sealed class ResultadoUssd {
    /** Ecrã de sucesso e os valores batem com o pedido. */
    data class Sucesso(val mb: Int, val numero: String, val saldoAntesMb: Int? = null) : ResultadoUssd()
    /** Ecrã de sucesso mas MB ou número diferentes do pedido → decisão humana. */
    data class Divergente(val ecra: String) : ResultadoUssd()
    /** O SIM tem menos megas do que o pedido. Nada foi enviado ao operador. Trocar de SIM. */
    data class SaldoInsuficiente(val saldoMb: Int) : ResultadoUssd()
    /** O operador recusou ANTES de pedirmos o destino. Nada foi transferido. */
    data class RecusadoAntesDoDestino(val ecra: String) : ResultadoUssd()
    data class Saldo(val mb: Int) : ResultadoUssd()
    /** "mínimo de 0 MB" DEPOIS de enviar o destino: pode ter transferido ou não → reconsultar saldo. */
    data class Ambiguo(val saldoAntesMb: Int?, val ecra: String) : ResultadoUssd()
    data class Desconhecido(val ecra: String, val enviouDestino: Boolean, val saldoAntesMb: Int?) : ResultadoUssd()
    data class TempoEsgotado(val enviouDestino: Boolean, val saldoAntesMb: Int?) : ResultadoUssd()
}

sealed class Passo {
    data class Enviar(val texto: String) : Passo()
    data class Terminar(val resultado: ResultadoUssd) : Passo()
    object Aguardar : Passo()
}

enum class FormatoDestino { NOVE_DIGITOS, COM_258 }

// ───────────── Leitura de ecrãs ─────────────

object Ecras {
    fun normalizar(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .lowercase(Locale.ROOT)
            .replace(Regex("\\s+"), " ")
            .trim()

    private val SUCESSO = Regex("""transferiste com sucesso\s+(\d+)\s*mb.*?para o numero\s+(\d{9,12})""")
    private val ERRO_MINIMO = Regex("""(?:tranferencia|transferencia) de megas nao permitida.*minimo de 0 mb""")
    private val SALDO = Regex("""saldo de dados:\s*(\d+)\s*mb""")

    fun classificar(raw: String): Ecra {
        val t = normalizar(raw)

        SUCESSO.find(t)?.let {
            return Ecra(TipoEcra.SUCESSO, mbTransferidos = it.groupValues[1].toInt(), numero = it.groupValues[2])
        }
        if (ERRO_MINIMO.containsMatchIn(t)) return Ecra(TipoEcra.ERRO_MINIMO)
        if ("quantos megas pretendes transferir" in t) {
            return Ecra(TipoEcra.PEDE_QUANTIDADE, saldoMb = SALDO.find(t)?.groupValues?.get(1)?.toIntOrNull())
        }
        if ("digita o numero do recipiente" in t) return Ecra(TipoEcra.PEDE_DESTINO)
        if (opcaoDoMenu(raw, "transferir megas") != null && opcaoDoMenu(raw, "consultar saldo") != null) {
            return Ecra(TipoEcra.MENU_INTERNET)
        }
        if (opcaoDoMenu(raw, "servicos de internet") != null && "por hora" in t) return Ecra(TipoEcra.MENU_PRINCIPAL)
        return Ecra(TipoEcra.DESCONHECIDO)
    }

    /** Descobre o dígito de uma opção pelo nome ("8. Servicos de Internet" → "8"). Não depende da ordem. */
    fun opcaoDoMenu(raw: String, rotulo: String): String? =
        Regex("""(\d+)\s*[.)]\s*${Regex.escape(rotulo)}""").find(normalizar(raw))?.groupValues?.get(1)
}

// ───────────── Sessão: o que enviar a cada ecrã ─────────────

/**
 * Receita Vodacom: *162# → "Servicos de Internet" → "Transferir Megas" → MB → número.
 * A sessão é um objeto por tentativa. Cada ecrã só recebe resposta UMA vez (nunca reenvia às cegas).
 */
class SessaoUssd(
    private val tarefa: Tarefa,
    private val formato: FormatoDestino = FormatoDestino.NOVE_DIGITOS
) {
    var enviouDestino = false
        private set
    var saldoAntesMb: Int? = null
        private set

    private var ultimoTexto: String? = null
    private val respondidos = mutableSetOf<TipoEcra>()

    fun aoVerEcra(raw: String): Passo {
        val norm = Ecras.normalizar(raw)
        if (norm == ultimoTexto) return Passo.Aguardar       // o Android repete eventos do mesmo ecrã
        ultimoTexto = norm

        val e = Ecras.classificar(raw)
        return when (e.tipo) {
            TipoEcra.MENU_PRINCIPAL -> responder(e.tipo, raw, Ecras.opcaoDoMenu(raw, "servicos de internet") ?: "8")
            TipoEcra.MENU_INTERNET -> responder(e.tipo, raw, Ecras.opcaoDoMenu(raw, "transferir megas") ?: "2")

            TipoEcra.PEDE_QUANTIDADE -> {
                saldoAntesMb = e.saldoMb
                when (tarefa) {
                    is Tarefa.ConsultarSaldo ->
                        Passo.Terminar(
                            e.saldoMb?.let { ResultadoUssd.Saldo(it) }
                                ?: ResultadoUssd.Desconhecido(raw, false, null)
                        )
                    is Tarefa.Transferir -> {
                        val saldo = e.saldoMb
                        if (saldo != null && saldo < tarefa.mb) {
                            Passo.Terminar(ResultadoUssd.SaldoInsuficiente(saldo))   // evita o ecrã ambíguo
                        } else {
                            responder(e.tipo, raw, tarefa.mb.toString())
                        }
                    }
                }
            }

            TipoEcra.PEDE_DESTINO -> when (tarefa) {
                is Tarefa.ConsultarSaldo -> Passo.Terminar(ResultadoUssd.Desconhecido(raw, false, saldoAntesMb))
                is Tarefa.Transferir -> {
                    val numero = if (formato == FormatoDestino.NOVE_DIGITOS) tarefa.destino.substring(3) else tarefa.destino
                    val p = responder(e.tipo, raw, numero)
                    if (p is Passo.Enviar) enviouDestino = true
                    p
                }
            }

            TipoEcra.SUCESSO -> when (tarefa) {
                is Tarefa.ConsultarSaldo -> Passo.Terminar(ResultadoUssd.Desconhecido(raw, enviouDestino, saldoAntesMb))
                is Tarefa.Transferir -> {
                    val bate = e.mbTransferidos == tarefa.mb && e.numero == tarefa.destino
                    Passo.Terminar(
                        if (bate) ResultadoUssd.Sucesso(tarefa.mb, tarefa.destino, saldoAntesMb) else ResultadoUssd.Divergente(raw)
                    )
                }
            }

            TipoEcra.ERRO_MINIMO -> Passo.Terminar(
                if (enviouDestino) ResultadoUssd.Ambiguo(saldoAntesMb, raw) else ResultadoUssd.RecusadoAntesDoDestino(raw)
            )

            TipoEcra.DESCONHECIDO -> Passo.Terminar(ResultadoUssd.Desconhecido(raw, enviouDestino, saldoAntesMb))
        }
    }

    fun aoExpirar(): ResultadoUssd = ResultadoUssd.TempoEsgotado(enviouDestino, saldoAntesMb)

    /** O serviço não conseguiu escrever/clicar. Se já enviámos o destino, o estado é incerto. */
    fun aoFalharInteracao(raw: String): ResultadoUssd = ResultadoUssd.Desconhecido(raw, enviouDestino, saldoAntesMb)

    private fun responder(tipo: TipoEcra, raw: String, valor: String): Passo =
        if (!respondidos.add(tipo)) {
            Passo.Terminar(ResultadoUssd.Desconhecido(raw, enviouDestino, saldoAntesMb))  // mesmo ecrã duas vezes = loop
        } else {
            Passo.Enviar(valor)
        }
}

// ───────────── Ecrã ambíguo: reconsultar o saldo ─────────────

enum class DecisaoAmbiguo { SUCESSO, FALHA, REVISAO }

object Ambiguo {
    /**
     * saldoAntes: lido no mesmo USSD antes de pedir a quantidade. saldoDepois: nova consulta.
     * Uma transferência real baixa o saldo em pelo menos `mb`; o consumo normal de dados é pequeno.
     */
    fun decidir(saldoAntes: Int?, saldoDepois: Int?, mb: Int): DecisaoAmbiguo {
        if (saldoAntes == null || saldoDepois == null) return DecisaoAmbiguo.REVISAO
        val baixou = saldoAntes - saldoDepois
        return when {
            baixou >= mb -> DecisaoAmbiguo.SUCESSO
            baixou in 0 until (mb / 2) -> DecisaoAmbiguo.FALHA
            else -> DecisaoAmbiguo.REVISAO      // subiu, ou baixou "meio caminho": não arriscar
        }
    }
}
