@file:OptIn(ExperimentalMaterial3Api::class)

package mz.neton

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.telephony.SubscriptionManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import mz.neton.data.*
import mz.neton.payments.Money
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val pedirPermissoes =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val lista = mutableListOf(
            Manifest.permission.RECEIVE_SMS, Manifest.permission.SEND_SMS,
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= 33) lista += Manifest.permission.POST_NOTIFICATIONS
        pedirPermissoes.launch(lista.toTypedArray())

        val app = application as App
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Raiz(app) } } }
    }
}

// ───────────── Utilidades ─────────────

fun mtTxt(c: Long): String = String.format(Locale.ROOT, "%d.%02d", c / 100, c % 100)

@Composable
fun <T> poll(inicial: T, carregar: suspend () -> T): State<T> =
    produceState(inicial) {
        while (true) {
            value = try { carregar() } catch (e: Exception) { value }
            delay(2000)
        }
    }

fun acessibilidadeAtiva(ctx: Context): Boolean {
    val s = android.provider.Settings.Secure.getString(
        ctx.contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    )
    return s != null && s.contains("UssdAccessibilityService")
}

@Composable
fun Raiz(app: App) {
    var aba by remember { mutableIntStateOf(0) }
    val abas = listOf("Painel", "Pedidos", "Pacotes", "SIMs", "Definições", "Testar")
    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = aba, edgePadding = 0.dp) {
            abas.forEachIndexed { i, t -> Tab(selected = aba == i, onClick = { aba = i }, text = { Text(t) }) }
        }
        when (aba) {
            0 -> PainelTela(app)
            1 -> PedidosTela(app)
            2 -> PacotesTela(app)
            3 -> SimsTela(app)
            4 -> DefinicoesTela(app)
            else -> TestarTela(app)
        }
    }
}

@Composable
fun Pagina(conteudo: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) { conteudo() }
}

// ───────────── Painel ─────────────

@Composable
fun PainelTela(app: App) {
    val ctx = LocalContext.current
    var ligado by remember { mutableStateOf(app.config.botLigado) }
    var simulacao by remember { mutableStateOf(app.config.simulacao) }
    val pedidos by poll(emptyList<PedidoEntity>()) { app.db.pedidos().ultimos(500) }
    val pagamentos by poll(emptyList<PagamentoEntity>()) { app.db.pagamentos().ultimos(500) }
    val logs by poll(emptyList<LogEntity>()) { app.db.logs().ultimos(40) }
    val acess by poll(false) { acessibilidadeAtiva(ctx) }

    Pagina {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Bot ligado", style = MaterialTheme.typography.titleMedium)
            Switch(checked = ligado, onCheckedChange = {
                ligado = it; app.config.botLigado = it
                if (it) BotService.iniciar(ctx) else BotService.parar(ctx)
            })
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("Modo simulação", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (simulacao) "Não marca USSD nem envia SMS (só regista)." else "REAL: marca USSD e envia SMS.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Switch(checked = simulacao, onCheckedChange = { simulacao = it; app.config.simulacao = it })
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("Pedidos: ${pedidos.count { it.estado == EstadoPedido.NA_FILA }} na fila · " +
                    "${pedidos.count { it.estado == EstadoPedido.CONCLUIDO }} concluídos · " +
                    "${pedidos.count { it.estado == EstadoPedido.REVISAO }} em revisão · " +
                    "${pedidos.count { it.estado == EstadoPedido.FALHOU }} falhados")
                Text("Pagamentos: ${pagamentos.size} · sem dono: ${pagamentos.count { it.estado == EstadoPagamento.SEM_DONO }} · " +
                    "carteira: ${pagamentos.count { it.estado == EstadoPagamento.CARTEIRA }}")
                Text("Acessibilidade USSD: " + if (acess) "ativa" else "DESLIGADA (precisa para o modo real)")
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { ctx.startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Acessibilidade") }
            OutlinedButton(onClick = { ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("Bateria") }
        }
        Text("Registo", style = MaterialTheme.typography.titleMedium)
        logs.forEach { Text("[${it.nivel}] ${it.mensagem}", style = MaterialTheme.typography.bodySmall) }
    }
}

// ───────────── Pedidos ─────────────

@Composable
fun PedidosTela(app: App) {
    val pedidos by poll(emptyList<PedidoEntity>()) { app.db.pedidos().ultimos(40) }
    val pagamentos by poll(emptyList<PagamentoEntity>()) { app.db.pagamentos().ultimos(30) }
    Pagina {
        Text("Pedidos", style = MaterialTheme.typography.titleMedium)
        pedidos.forEach { p ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text("#${p.id} · ${p.estado} · ${p.mb} MB → ${p.destino.removePrefix("258")} · ${mtTxt(p.valorCentavos)} MT · ${p.canal}")
                    p.mensagemEcra?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                    if (p.estado == EstadoPedido.REVISAO) {
                        Text("Verifique no número de destino se os megas chegaram:", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { app.scope.launch { app.bot.executor.resolverRevisao(p.id, true) } }) { Text("Chegaram") }
                            OutlinedButton(onClick = { app.scope.launch { app.bot.executor.resolverRevisao(p.id, false) } }) { Text("Não chegaram") }
                        }
                    }
                    if (p.estado == EstadoPedido.FALHOU && p.canal != Canal.CARTEIRA) {
                        Button(onClick = {
                            app.scope.launch { if (app.bot.executor.reenviar(p.id)) app.bot.acordarFila() }
                        }) { Text("Reenviar") }
                    }
                }
            }
        }
        Text("Pagamentos", style = MaterialTheme.typography.titleMedium)
        pagamentos.forEach {
            Text("${it.chave} · ${mtTxt(it.valorCentavos)} MT · ${it.estado}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

// ───────────── Pacotes ─────────────

private val EXEMPLOS: List<Triple<Familia, Int, Int>> = listOf(
    Triple(Familia.DIARIO, 5, 195), Triple(Familia.DIARIO, 6, 240), Triple(Familia.DIARIO, 7, 280),
    Triple(Familia.DIARIO, 8, 320), Triple(Familia.DIARIO, 9, 385), Triple(Familia.DIARIO, 10, 426),
    Triple(Familia.DIARIO, 11, 476), Triple(Familia.DIARIO, 12, 525), Triple(Familia.DIARIO, 13, 575),
    Triple(Familia.DIARIO, 14, 600), Triple(Familia.DIARIO, 15, 650), Triple(Familia.DIARIO, 22, 1024),
    Triple(Familia.SEMANAL, 49, 1741), Triple(Familia.SEMANAL, 81, 2970), Triple(Familia.SEMANAL, 143, 5325),
    Triple(Familia.SEMANAL, 190, 7270), Triple(Familia.SEMANAL, 285, 10957), Triple(Familia.SEMANAL, 390, 14643),
    Triple(Familia.MENSAL, 290, 10715), Triple(Familia.MENSAL, 480, 18316), Triple(Familia.MENSAL, 950, 36631),
    Triple(Familia.MENSAL, 1450, 54886), Triple(Familia.MENSAL, 1900, 73216), Triple(Familia.MENSAL, 2350, 91546)
)

@Composable
fun PacotesTela(app: App) {
    val pacotes by poll(emptyList<PacoteEntity>()) { app.db.pacotes().todos() }
    var familia by remember { mutableStateOf(Familia.DIARIO) }
    var preco by remember { mutableStateOf("") }
    var mb by remember { mutableStateOf("") }
    var texto by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }

    Pagina {
        Text("Tabela de pacotes", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Familia.values().forEach { f ->
                FilterChip(selected = familia == f, onClick = { familia = f }, label = { Text(f.name) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(preco, { preco = it }, label = { Text("Preço (MT)") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(mb, { mb = it }, label = { Text("Megas (MB)") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        Button(onClick = {
            val c = Money.parseCentavos(preco.replace(',', '.'))
            val m = mb.trim().toIntOrNull()
            if (c != null && c > 0 && m != null && m > 0) {
                app.scope.launch { app.db.pacotes().guardar(PacoteEntity(familia = familia, precoCentavos = c, mb = m)) }
                preco = ""; mb = ""; msg = "Guardado."
            } else msg = "Preço ou megas inválidos."
        }) { Text("Adicionar / atualizar em $familia") }

        OutlinedTextField(
            texto, { texto = it }, modifier = Modifier.fillMaxWidth(), minLines = 3,
            label = { Text("Importar: uma linha por pacote, ex.: 16 700") }
        )
        OutlinedButton(onClick = {
            var n = 0
            val re = Regex("""(\d+(?:[.,]\d{1,2})?)\D+(\d+)""")
            texto.lines().forEach { linha ->
                val m = re.find(linha) ?: return@forEach
                val c = Money.parseCentavos(m.groupValues[1].replace(',', '.'))
                val mbs = m.groupValues[2].toIntOrNull()
                if (c != null && c > 0 && mbs != null && mbs > 0) {
                    app.scope.launch { app.db.pacotes().guardar(PacoteEntity(familia = familia, precoCentavos = c, mb = mbs)) }
                    n++
                }
            }
            msg = "$n linha(s) importada(s) para $familia."
        }) { Text("Importar para $familia") }
        OutlinedButton(onClick = {
            app.scope.launch {
                EXEMPLOS.forEach { (f, p, m) -> app.db.pacotes().guardar(PacoteEntity(familia = f, precoCentavos = p * 100L, mb = m)) }
            }
            msg = "Exemplos do documento carregados. REVEJA os valores."
        }) { Text("Carregar exemplos do documento") }
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall)

        pacotes.groupBy { it.familia }.forEach { (f, lista) ->
            Text("$f (${lista.size})", style = MaterialTheme.typography.titleSmall)
            lista.forEach { p ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${mtTxt(p.precoCentavos)} MT → ${p.mb} MB")
                    TextButton(onClick = { app.scope.launch { app.db.pacotes().apagar(p.id) } }) { Text("Apagar") }
                }
            }
        }
    }
}

// ───────────── SIMs ─────────────

@SuppressLint("MissingPermission")
suspend fun detetarSims(app: App): Int {
    val sm = app.getSystemService(SubscriptionManager::class.java) ?: return 0
    val lista = sm.activeSubscriptionInfoList ?: return 0
    var n = 0
    for (i in lista) {
        val mccmnc = if (Build.VERSION.SDK_INT >= 29) "${i.mccString}${i.mncString}" else "${i.mcc}${i.mnc}"
        val nome = (i.carrierName ?: "").toString().lowercase()
        val op = when {
            mccmnc == "64304" || "vodacom" in nome -> "vodacom"
            mccmnc == "64303" || "movitel" in nome -> "movitel"
            else -> "desconhecida"
        }
        val numero = i.number?.takeIf { it.isNotBlank() }
        if (app.db.sims().inserirSeNovo(SimEntity(subId = i.subscriptionId, operadora = op, numero = numero)) != -1L) n++
    }
    return n
}

@Composable
fun SimsTela(app: App) {
    val sims by poll(emptyList<SimEntity>()) { app.db.sims().todos() }
    var msg by remember { mutableStateOf("") }
    Pagina {
        Text("SIMs", style = MaterialTheme.typography.titleMedium)
        Text("Só SIMs Vodacom ativos executam transferências (receita *162#).", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { app.scope.launch { msg = "${detetarSims(app)} SIM(s) novo(s) detetado(s)." } }) { Text("Detetar SIMs") }
            OutlinedButton(onClick = {
                app.scope.launch { app.db.sims().inserirSeNovo(SimEntity(subId = 99, operadora = "vodacom", numero = "84TESTE")) }
                msg = "SIM de teste criado (subId 99)."
            }) { Text("SIM de teste") }
        }
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall)
        sims.forEach { s ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text("SIM ${s.subId} · ${s.operadora} · ${s.numero ?: "número desconhecido"}")
                    Text("Hoje ${s.usosHoje}/${s.limiteDiario} · saldo ${s.saldoMb?.let { "$it MB" } ?: "?"}", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Ativo")
                        Switch(checked = s.ativo, onCheckedChange = { app.scope.launch { app.db.sims().definirAtivo(s.subId, it) } })
                        TextButton(onClick = {
                            val novo = if (s.operadora == "vodacom") "movitel" else "vodacom"
                            app.scope.launch { app.db.sims().definirOperadora(s.subId, novo) }
                        }) { Text("Mudar operadora") }
                    }
                }
            }
        }
    }
}

// ───────────── Definições ─────────────

@Composable
fun DefinicoesTela(app: App) {
    val c = app.config
    var negocio by remember { mutableStateOf(c.negocio) }
    var grupo by remember { mutableStateOf(c.grupo) }
    var dono by remember { mutableStateOf(c.dono) }
    var custo by remember { mutableStateOf(if (c.custoGbCentavos == 0L) "" else mtTxt(c.custoGbCentavos)) }
    var remetentes by remember { mutableStateOf(c.remetentes) }
    var destino9 by remember { mutableStateOf(c.destino9) }
    var msg by remember { mutableStateOf("") }

    Pagina {
        Text("Definições", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(negocio, { negocio = it }, label = { Text("Nome do negócio (assina as mensagens)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(grupo, { grupo = it }, label = { Text("Grupo: nome ou link de convite (opcional)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(dono, { dono = it }, label = { Text("Número do dono para alertas por SMS") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(custo, { custo = it }, label = { Text("Custo por GB (MT), só para calcular o lucro") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(remetentes, { remetentes = it }, label = { Text("Remetentes oficiais (separados por vírgula)") }, modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("Enviar destino com 9 dígitos")
                Text("Desligado = envia com 258 à frente.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = destino9, onCheckedChange = { destino9 = it })
        }
        Button(onClick = {
            c.negocio = negocio.trim(); c.grupo = grupo.trim(); c.dono = dono.trim()
            c.custoGbCentavos = Money.parseCentavos(custo.replace(',', '.')) ?: 0L
            c.remetentes = remetentes; c.destino9 = destino9
            msg = "Guardado."
        }) { Text("Guardar") }
        if (msg.isNotEmpty()) Text(msg)
    }
}

// ───────────── Testar (sem gastar nada) ─────────────

private fun novoPP(): String {
    return "PP261101.${(1000..2359).random()}.${('A'..'Z').random()}${(10000..99999).random()}"
}

private fun novoMP(): String {
    val letras = ('A'..'Z') + ('0'..'9')
    return "DJV" + (1..8).map { letras.random() }.joinToString("")
}

private data class Exemplo(val rotulo: String, val remetente: String, val texto: String)

private val EXEMPLOS_SMS = listOf(
    Exemplo("e-Mola 10 MT com número", "eMola",
        "ID Trans: {PP}. Recebeu 10.00MT de 874000001, CLIENTE TESTE as 12:00:00 01/11/2026. Conteudo: 850000002. O seu novo saldo e de 50.00MT. Em caso de duvida, ligue para 100."),
    Exemplo("e-Mola 10 MT sem número", "eMola",
        "ID Trans: {PP}. Recebeu 10.00MT de 874000001, CLIENTE TESTE as 12:00:00 01/11/2026. Conteudo: . O seu novo saldo e de 50.00MT. Em caso de duvida, ligue para 100."),
    Exemplo("M-Pesa 10 MT", "M-Pesa",
        "Confirmado {MP}. Recebeste 10.00MT de 258845000001 - CLIENTE TESTE aos 1/11/26 as 12:00 PM. O teu novo saldo M-Pesa e de 50.00MT. Em caso de duvida, liga 100. M-Pesa e facil!"),
    Exemplo("e-Mola 17 MT (fora da tabela)", "eMola",
        "ID Trans: {PP}. Recebeu 17.00MT de 874000001, CLIENTE TESTE as 12:00:00 01/11/2026. Conteudo: . O seu novo saldo e de 50.00MT. Em caso de duvida, ligue para 100."),
    Exemplo("Resposta do pagador com número", "258874000001", "850000003"),
    Exemplo("e-Mola 49 MT (semanal)", "eMola",
        "ID Trans: {PP}. Recebeu 49.00MT de 874000001, CLIENTE TESTE as 12:00:00 01/11/2026. Conteudo: 850000002. O seu novo saldo e de 99.00MT. Em caso de duvida, ligue para 100.")
)

private val EXEMPLOS_GRUPO = listOf(
    Exemplo("Comprovativo e-Mola 10 MT", "258874000001",
        "ID da transacao {PP}. Transferiste 10.00MT para conta 864000005, nome: NEGOCIO TESTE as 12:00:00 de 01/11/2026. Taxa: 0.00MT. O saldo da tua conta e 1.00 MT. Conteudo: 1. Em caso de duvida, liga 100. Obrigado!"),
    Exemplo("Comprovativo M-Pesa 10 MT", "258845000001",
        "Confirmado {MP}. Transferiste 10.00MT e a taxa foi de 0.00MT para 845000009 - NEGOCIO aos 1/11/26 as 12:00 PM. O teu novo saldo M-Pesa e de 5.00MT."),
    Exemplo("Número de destino", "258874000001", "850000003")
)

@Composable
fun TestarTela(app: App) {
    var pp by remember { mutableStateOf(novoPP()) }
    var mp by remember { mutableStateOf(novoMP()) }
    var remetente by remember { mutableStateOf("eMola") }
    var corpo by remember { mutableStateOf(EXEMPLOS_SMS[0].texto) }
    var cliente by remember { mutableStateOf("258874000001") }
    var grupoTexto by remember { mutableStateOf(EXEMPLOS_GRUPO[0].texto) }
    var msg by remember { mutableStateOf("") }
    fun fill(t: String) = t.replace("{PP}", pp).replace("{MP}", mp)

    Pagina {
        Text("Testar sem gastar nada", style = MaterialTheme.typography.titleMedium)
        Text("O bot precisa de estar LIGADO no Painel. Em simulação nada real é enviado.", style = MaterialTheme.typography.bodySmall)
        Text("IDs deste teste: $pp / $mp", style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = { pp = novoPP(); mp = novoMP() }) { Text("Gerar IDs novos (um pagamento = um ID)") }

        Text("1) SMS recebido no aparelho", style = MaterialTheme.typography.titleSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            EXEMPLOS_SMS.forEach { e -> OutlinedButton(onClick = { remetente = e.remetente; corpo = e.texto }) { Text(e.rotulo) } }
        }
        OutlinedTextField(remetente, { remetente = it }, label = { Text("Remetente") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(corpo, { corpo = it }, label = { Text("Texto do SMS") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        Button(onClick = {
            app.scope.launch { app.bot.aoReceberSms(remetente, fill(corpo)); app.bot.acordarFila() }
            msg = "SMS simulado enviado. Veja o Painel e os Pedidos."
        }) { Text("Simular SMS recebido") }

        Text("2) Mensagem de um cliente no grupo", style = MaterialTheme.typography.titleSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            EXEMPLOS_GRUPO.forEach { e -> OutlinedButton(onClick = { cliente = e.remetente; grupoTexto = e.texto }) { Text(e.rotulo) } }
        }
        OutlinedTextField(cliente, { cliente = it }, label = { Text("Número WhatsApp do cliente") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(grupoTexto, { grupoTexto = it }, label = { Text("Mensagem no grupo") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        Button(onClick = {
            app.scope.launch { app.bot.simularGrupo(cliente, fill(grupoTexto)); app.bot.acordarFila() }
            msg = "Mensagem de grupo simulada. Veja o registo no Painel."
        }) { Text("Simular mensagem no grupo") }
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.width(1.dp))
    }
}
