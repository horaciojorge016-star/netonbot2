package mz.neton

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import mz.neton.data.AppDatabase

class App : Application() {
    val db: AppDatabase by lazy { AppDatabase.get(this) }
    val config: ConfigStore by lazy { ConfigStore(this) }
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val bot: Bot by lazy { Bot(this) }

    override fun onCreate() {
        super.onCreate()
        // Pedidos que ficaram "em execução" quando a app fechou → revisão (nunca reenvio automático).
        scope.launch {
            try { bot.executor.recuperarAposReinicio() } catch (e: Exception) { bot.log("ERRO", "Recuperação: ${e.message}") }
        }
    }
}
