package mz.neton.engine

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.runBlocking
import mz.neton.data.*
import mz.neton.payments.Operadora
import mz.neton.ussd.ResultadoUssd
import mz.neton.ussd.Tarefa
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Corre no EMULADOR ou telemóvel (pasta androidTest). Não marca USSD a sério: usa um USSD falso.
 * Dependências: androidTestImplementation("androidx.test.ext:junit:1.1.5") e ("androidx.test:core:1.5.0")
 */
@RunWith(AndroidJUnit4::class)
class ExecutorTest {

    private lateinit var db: AppDatabase
    private var t = 1_800_000_000_000L
    private val efeitos = FakeEfeitos()
    private val DEST = "258857000001"
    private val CLIENTE = "258874000001"

    @Before fun abrir() {
        db = AppDatabase.emMemoria(ApplicationProvider.getApplicationContext())
    }

    @After fun fechar() = db.close()

    // ───── ajudas ─────

    private class FakeRunner(vararg r: ResultadoUssd) : UssdRunner {
        val respostas = ArrayDeque(r.toList())
        val chamadas = mutableListOf<Pair<Tarefa, Int>>()
        override suspend fun executar(tarefa: Tarefa, subId: Int): ResultadoUssd {
            chamadas += tarefa to subId
            return respostas.removeFirst()
        }
    }

    private class FakeEfeitos : Efeitos {
        val sms = mutableListOf<Pair<String, String>>()
        val grupo = mutableListOf<Triple<String?, String, String>>()
        val alertas = mutableListOf<String>()
        override suspend fun enviarSms(para: String, texto: String) { sms += para to texto }
        override suspend fun responderGrupo(grupoId: String?, cliente: String, texto: String) { grupo += Triple(grupoId, cliente, texto) }
        override suspend fun avisarDono(texto: String) { alertas += texto }
    }

    private fun executor(r: UssdRunner) =
        Executor(db, r, efeitos, { ExecSettings(negocio = "Loja", custoPorGbCentavos = 1761) }, { t })

    private suspend fun dosSims() {
        db.sims().guardar(SimEntity(1, "vodacom", "841111111"))
        db.sims().guardar(SimEntity(2, "vodacom", "842222222"))
    }

    private suspend fun pedido(canal: Canal = Canal.SMS, mb: Int = 100, valor: Long = 1000, comPagamento: Boolean = true): Long {
        if (comPagamento) {
            db.pagamentos().inserir(
                PagamentoEntity(
                    chave = "emola:PP1", operadora = Operadora.EMOLA, valorCentavos = valor, pagadorNumero = CLIENTE,
                    pagadorNome = "X", recebidoEm = t, estado = EstadoPagamento.USADO, atualizadoEm = t
                )
            )
        }
        return db.pedidos().inserir(
            PedidoEntity(
                pagamentoChave = if (comPagamento) "emola:PP1" else null, clienteNumero = CLIENTE, destino = DEST,
                pacoteId = null, mb = mb, valorCentavos = valor, canal = canal, estado = EstadoPedido.NA_FILA,
                criadoEm = t, atualizadoEm = t
            )
        )
    }

    private suspend fun simUsos(subId: Int) = db.sims().ativos().first { it.subId == subId }.usosHoje

    // ───── testes ─────

    @Test fun sucesso() = runBlocking {
        dosSims(); val id = pedido()
        val runner = FakeRunner(ResultadoUssd.Sucesso(100, DEST, 580))
        executor(runner).processarFila()

        val p = db.pedidos().porId(id)!!
        assertEquals(EstadoPedido.CONCLUIDO, p.estado)
        assertEquals(EstadoPagamento.CONCLUIDO, db.pagamentos().porChave("emola:PP1")!!.estado)
        assertEquals(1000L - 100L * 1761 / 1024, p.lucroCentavos)
        val sim = db.sims().ativos().first { it.subId == p.simSubId }
        assertEquals(1, sim.usosHoje)
        assertEquals(480, sim.saldoMb)
        assertEquals(1, efeitos.sms.size)
        assertTrue(efeitos.sms[0].second.contains("TRANSFERÊNCIA CONCLUÍDA"))
    }

    @Test fun saldoInsuficienteNumSimTentaOOutro() = runBlocking {
        dosSims(); val id = pedido()
        val runner = FakeRunner(ResultadoUssd.SaldoInsuficiente(50), ResultadoUssd.Sucesso(100, DEST, 300))
        executor(runner).processarFila()

        assertEquals(EstadoPedido.CONCLUIDO, db.pedidos().porId(id)!!.estado)
        val (primeiro, segundo) = runner.chamadas.map { it.second }
        assertNotEquals(primeiro, segundo)
        assertEquals(0, simUsos(primeiro))     // quota devolvida
        assertEquals(1, simUsos(segundo))
    }

    @Test fun semSaldoEmNenhumSim_ficaNaFila_semReembolsoESemRepetirLogo() = runBlocking {
        dosSims(); val id = pedido()
        val runner = FakeRunner(
            ResultadoUssd.SaldoInsuficiente(10), ResultadoUssd.SaldoInsuficiente(20),
            ResultadoUssd.Sucesso(100, DEST, 400)
        )
        val ex = executor(runner)
        ex.processarFila()
        assertEquals(EstadoPedido.NA_FILA, db.pedidos().porId(id)!!.estado)
        assertEquals(EstadoPagamento.USADO, db.pagamentos().porChave("emola:PP1")!!.estado)
        assertEquals(1, efeitos.alertas.size)
        assertEquals(2, runner.chamadas.size)

        ex.processarFila()                      // dentro da pausa: não marca USSD
        assertEquals(2, runner.chamadas.size)

        t += 6 * 60_000L                        // passou a pausa
        ex.processarFila()
        assertEquals(EstadoPedido.CONCLUIDO, db.pedidos().porId(id)!!.estado)
        assertEquals(3, runner.chamadas.size)
    }

    @Test fun ambiguo_saldoBaixou_contaComoSucesso() = runBlocking {
        dosSims(); val id = pedido()
        val runner = FakeRunner(ResultadoUssd.Ambiguo(580, "mínimo de 0 MB"), ResultadoUssd.Saldo(480))
        executor(runner).processarFila()

        assertEquals(EstadoPedido.CONCLUIDO, db.pedidos().porId(id)!!.estado)
        assertTrue(runner.chamadas[1].first is Tarefa.ConsultarSaldo)
        assertEquals(1, runner.chamadas.size - 1)
    }

    @Test fun ambiguo_saldoIgual_foiFalha_tentaOutroSim() = runBlocking {
        dosSims(); val id = pedido()
        val runner = FakeRunner(
            ResultadoUssd.Ambiguo(580, "mínimo de 0 MB"), ResultadoUssd.Saldo(580), ResultadoUssd.Sucesso(100, DEST, 300)
        )
        executor(runner).processarFila()

        assertEquals(EstadoPedido.CONCLUIDO, db.pedidos().porId(id)!!.estado)
        val primeiro = runner.chamadas[0].second
        assertEquals(0, simUsos(primeiro))
    }

    @Test fun duvidaDepoisDeEnviarODestino_vaiParaRevisao_eNaoReenvia() = runBlocking {
        dosSims(); val id = pedido()
        val runner = FakeRunner(ResultadoUssd.Desconhecido("???", true, 580), ResultadoUssd.Saldo(530))
        executor(runner).processarFila()

        assertEquals(EstadoPedido.REVISAO, db.pedidos().porId(id)!!.estado)
        assertEquals(EstadoPagamento.REVISAO, db.pagamentos().porChave("emola:PP1")!!.estado)
        assertEquals(2, runner.chamadas.size)   // transferência + consulta; nenhum segundo SIM
        assertTrue(efeitos.alertas.isNotEmpty())
    }

    @Test fun ecraDeSucessoDivergente_vaiParaRevisao_equotaFicaGasta() = runBlocking {
        dosSims(); val id = pedido()
        val runner = FakeRunner(ResultadoUssd.Divergente("Transferiste com sucesso 200MB ..."))
        executor(runner).processarFila()

        assertEquals(EstadoPedido.REVISAO, db.pedidos().porId(id)!!.estado)
        assertEquals(1, simUsos(runner.chamadas[0].second))
    }

    @Test fun falhaNaCarteira_devolveOSaldo() = runBlocking {
        dosSims()
        db.carteira().creditar(CLIENTE, 1000, "emola:PP0", t)
        val id = pedido(canal = Canal.CARTEIRA, comPagamento = false)
        assertEquals(ResultadoMov.OK, db.carteira().reservar(CLIENTE, 1000, id, t))
        assertEquals(0L, db.carteira().saldo(CLIENTE))

        val runner = FakeRunner(ResultadoUssd.RecusadoAntesDoDestino("x"), ResultadoUssd.RecusadoAntesDoDestino("x"))
        executor(runner).processarFila()

        assertEquals(EstadoPedido.FALHOU, db.pedidos().porId(id)!!.estado)
        assertEquals(1000L, db.carteira().saldo(CLIENTE))
        assertEquals(1, efeitos.grupo.size)
    }

    @Test fun reinicioDuranteExecucao_vaiParaRevisao() = runBlocking {
        dosSims(); val id = pedido()
        db.pedidos().mudarEstado(id, EstadoPedido.NA_FILA, EstadoPedido.EM_EXECUCAO, t)
        executor(FakeRunner()).recuperarAposReinicio()
        assertEquals(EstadoPedido.REVISAO, db.pedidos().porId(id)!!.estado)
    }

    @Test fun donoConfirmaQueNaoChegou_reembolsa() = runBlocking {
        dosSims()
        db.carteira().creditar(CLIENTE, 1000, "emola:PP0", t)
        val id = pedido(canal = Canal.CARTEIRA, comPagamento = false)
        db.carteira().reservar(CLIENTE, 1000, id, t)
        val runner = FakeRunner(ResultadoUssd.Divergente("x"))
        val ex = executor(runner)
        ex.processarFila()
        assertEquals(0L, db.carteira().saldo(CLIENTE))   // continua reservado

        assertTrue(ex.resolverRevisao(id, entregue = false))
        assertEquals(EstadoPedido.FALHOU, db.pedidos().porId(id)!!.estado)
        assertEquals(1000L, db.carteira().saldo(CLIENTE))
    }
}
