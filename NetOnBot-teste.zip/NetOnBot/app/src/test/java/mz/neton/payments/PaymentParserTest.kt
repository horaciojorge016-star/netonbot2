package mz.neton.payments

import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

/** Todos os números e nomes são FICTÍCIOS. */
class PaymentParserTest {

    private val parser = PaymentParser()

    private val emolaVazio =
        "Pagamentos recebido: ID Trans: PP261031.1620.L14307. Recebeu 23.00MT de 874000001, CLIENTE UM DA SILVA as 16:20:06 31/10/2026. Conteudo: . O seu novo saldo e de 70.50MT. Em caso de duvida, ligue para 100."

    private val emolaComNumero =
        "ID Trans: PP261031.1906.H60169. Recebeu 30.00MT de 874000002, CLIENTE DOIS as 19:06:56 31/10/2026. Conteudo: 850000003. O seu novo saldo e de 115.50MT. Em caso de duvida, ligue para 100."

    private val mpesaRecebido =
        "Confirmado DJV9M5SCI59. Recebeste 23.00MT de 258855000004 - LUISA FICTICIA aos 31/10/26 as 7:25 PM. O teu novo saldo M-Pesa e de 82.00MT. Em caso de duvida, liga 100. M-Pesa e facil!"

    private val emolaProva =
        "ID da transacao PP261031.1456.B75050. Transferiste 10.00MT para conta 864000005, nome: NEGOCIO TESTE as 14:56:14 de 31/10/2026. Taxa: 0.00MT. O saldo da tua conta e 1.00 MT. Conteudo: 1. Em caso de duvida, liga 100. Obrigado!"

    private val mpesaProva =
        "Confirmado DJV1M5Q2DKD. Transferiste 5.00MT e a taxa foi de 0.00MT para 853000006 - NEGOCIO TESTE aos 31/10/26 as 5:39 PM. O teu novo saldo M-Pesa e de 1.90MT. Continua a transferir SEM TAXAS de M-Pesa para M-Pesa. Em caso de duvida, liga 100."

    private fun ms(y: Int, mo: Int, d: Int, h: Int, mi: Int, s: Int) =
        ZonedDateTime.of(y, mo, d, h, mi, s, 0, ZoneId.of("Africa/Maputo")).toInstant().toEpochMilli()

    @Test fun emolaRecebido_conteudoVazio() {
        val r = parser.parseOfficialSms("eMola", emolaVazio)
        assertEquals(1, r.size)
        val p = r[0]
        assertEquals("emola:PP261031.1620.L14307", p.chave)
        assertEquals(2300L, p.valorCentavos)
        assertEquals("258874000001", p.contraparte)
        assertNull(p.destinoVodacom)
        assertEquals(ms(2026, 10, 31, 16, 20, 6), p.timestampMs)
    }

    @Test fun emolaRecebido_conteudoComNumeroVodacom() {
        val p = parser.parseOfficialSms("eMola", emolaComNumero).single()
        assertEquals(3000L, p.valorCentavos)
        assertEquals("258850000003", p.destinoVodacom)
    }

    @Test fun emolaRecebido_conteudoMovitelNaoServeDeDestino() {
        val txt = emolaComNumero.replace("850000003", "860000003")
        assertNull(parser.parseOfficialSms("eMola", txt).single().destinoVodacom)
    }

    @Test fun mpesaRecebido_horaDe12h() {
        val p = parser.parseOfficialSms("M-Pesa", mpesaRecebido).single()
        assertEquals("mpesa:DJV9M5SCI59", p.chave)
        assertEquals(2300L, p.valorCentavos)
        assertEquals("258855000004", p.contraparte)
        assertEquals(ms(2026, 10, 31, 19, 25, 0), p.timestampMs)
    }

    @Test fun varios_SMS_colados_juntos() {
        val r = parser.parseOfficialSms("eMola", emolaVazio + emolaComNumero)
        assertEquals(2, r.size)
        assertEquals(setOf("emola:PP261031.1620.L14307", "emola:PP261031.1906.H60169"), r.map { it.chave }.toSet())
    }

    @Test fun remetenteNaoOficialEIgnorado() {
        assertTrue(parser.parseOfficialSms("+258840000000", mpesaRecebido).isEmpty())
        assertTrue(parser.parseOfficialSms(null, mpesaRecebido).isEmpty())
    }

    @Test fun remetente_semDistinguirMaiusculas() {
        assertTrue(parser.isOfficialSender("MPESA"))
        assertTrue(parser.isOfficialSender("e-mola"))
        assertFalse(parser.isOfficialSender("M-Pesa Promo"))
    }

    @Test fun smsOficialDeEnvioNaoContaComoPagamento() {
        assertTrue(parser.parseOfficialSms("M-Pesa", mpesaProva).isEmpty())
        assertTrue(parser.parseOfficialSms("eMola", emolaProva).isEmpty())
    }

    @Test fun comprovativoEmola() {
        val p = parser.parseProof(emolaProva).single()
        assertEquals(Origem.COMPROVATIVO, p.origem)
        assertEquals("emola:PP261031.1456.B75050", p.chave)
        assertEquals(1000L, p.valorCentavos)
        assertEquals("258864000005", p.contraparte)
        assertEquals("1", p.conteudoBruto)
        assertNull(p.destinoVodacom)
        assertEquals(ms(2026, 10, 31, 14, 56, 14), p.timestampMs)
    }

    @Test fun comprovativoMpesa() {
        val p = parser.parseProof(mpesaProva).single()
        assertEquals("mpesa:DJV1M5Q2DKD", p.chave)
        assertEquals(500L, p.valorCentavos)
        assertEquals("258853000006", p.contraparte)
        assertEquals(ms(2026, 10, 31, 17, 39, 0), p.timestampMs)
    }

    @Test fun comprovativoNaoMisturaConteudoDeOutroSms() {
        val a = emolaProva.replace("Conteudo: 1.", "Conteudo: .")
        val b = emolaProva.replace("B75050", "C99999").replace("Conteudo: 1.", "Conteudo: 850000009.")
        val r = parser.parseProof(a + " " + b)
        assertEquals(2, r.size)
        assertNull(r[0].destinoVodacom)
        assertEquals("258850000009", r[1].destinoVodacom)
    }

    @Test fun comprovativoColadoDuasVezesContaUmaVez() {
        assertEquals(1, parser.parseProof(mpesaProva + "\n" + mpesaProva).size)
    }

    @Test fun textoQualquerNaoGeraPagamento() {
        assertTrue(parser.parseProof("quero 1gb por favor").isEmpty())
        assertTrue(parser.parseOfficialSms("M-Pesa", "Promocao: recarregue e ganhe").isEmpty())
    }

    @Test fun telefone() {
        assertEquals("258857000000", Phone.normalize("857000000"))
        assertEquals("258857000000", Phone.normalize("+258 85 700 0000"))
        assertNull(Phone.normalize("12345"))
        assertTrue(Phone.isVodacom("258841234567"))
        assertTrue(Phone.isVodacom("258851234567"))
        assertFalse(Phone.isVodacom("258861234567"))
        assertFalse(Phone.isVodacom("258871234567"))
        assertFalse(Phone.isVodacom(null))
    }

    @Test fun dinheiroEmCentavos() {
        assertEquals(2300L, Money.parseCentavos("23.00"))
        assertEquals(150050L, Money.parseCentavos("1,500.50"))
        assertEquals(1050L, Money.parseCentavos("10.5"))
        assertEquals(500L, Money.parseCentavos("5"))
        assertNull(Money.parseCentavos("abc"))
    }

    @Test fun horas() {
        assertEquals(ms(2026, 10, 31, 0, 5, 0), TimeParser.parse("31/10/26", "12:05 AM"))
        assertEquals(ms(2026, 10, 31, 12, 5, 0), TimeParser.parse("31/10/2026", "12:05 PM"))
        assertNull(TimeParser.parse("31-10-2026", "12:05 PM"))
    }
}
