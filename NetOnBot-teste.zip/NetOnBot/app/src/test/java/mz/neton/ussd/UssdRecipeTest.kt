package mz.neton.ussd

import org.junit.Assert.*
import org.junit.Test

/** Ecrãs copiados dos prints reais (número de destino fictício). */
class UssdRecipeTest {

    private val menuPrincipal = "1. WFTTI+\n2. Por Hora\n3. Diario\n4. Semanal\n5. Mensal\n6. Infinito\n7. Tikete (NetFlix/Game)\n8. Servicos de Internet\n9. Voltar"
    private val menuInternet = "1. Consultar Saldo\n2. Transferir Megas\n3. Velocidades de Internet\n4. NetControl\n5. Meu estado 4.5G\n6. Configurar Internet\n0)Voltar (00.Inicio)"
    private val pedeQuantidade = "Saldo de dados: 580 MB\n\nPodes transferir megas entre 100MB\ne 10240MB, ate 10X/dia.Os megas\ntransferidos sao validos por 24h. Quantos\nmegas pretendes transferir?"
    private val pedeDestino = "Digita o numero do recipiente"
    private val erroMinimo = "Tranferencia de megas nao permitida. Apos a\ntransferencia de megas tens que ficar com um\nminimo de 0 MB. Obrigado"
    private fun sucesso(mb: Int, n: String) = "Transferiste com sucesso ${mb}MB validos por 24h,\npara o numero $n"

    private val destino = "258857000001"
    private fun tarefa(mb: Int = 100) = Tarefa.Transferir(mb, destino)

    private fun enviar(p: Passo) = (p as Passo.Enviar).texto
    private fun terminar(p: Passo) = (p as Passo.Terminar).resultado

    // ───── classificador ─────

    @Test fun classificaOsSeisEcras() {
        assertEquals(TipoEcra.MENU_PRINCIPAL, Ecras.classificar(menuPrincipal).tipo)
        assertEquals(TipoEcra.MENU_INTERNET, Ecras.classificar(menuInternet).tipo)
        assertEquals(TipoEcra.PEDE_QUANTIDADE, Ecras.classificar(pedeQuantidade).tipo)
        assertEquals(TipoEcra.PEDE_DESTINO, Ecras.classificar(pedeDestino).tipo)
        assertEquals(TipoEcra.ERRO_MINIMO, Ecras.classificar(erroMinimo).tipo)
        assertEquals(TipoEcra.SUCESSO, Ecras.classificar(sucesso(100, destino)).tipo)
    }

    @Test fun lerValoresDosEcras() {
        assertEquals(580, Ecras.classificar(pedeQuantidade).saldoMb)
        val s = Ecras.classificar(sucesso(100, destino))
        assertEquals(100, s.mbTransferidos)
        assertEquals(destino, s.numero)
    }

    @Test fun erroAceitaAsDuasGrafias() {
        assertEquals(TipoEcra.ERRO_MINIMO, Ecras.classificar(erroMinimo.replace("Tranferencia", "Transferencia")).tipo)
        assertEquals(TipoEcra.ERRO_MINIMO, Ecras.classificar(erroMinimo.replace("nao", "não")).tipo)
    }

    @Test fun ecraNovoENaoReconhecido() {
        assertEquals(TipoEcra.DESCONHECIDO, Ecras.classificar("Numero invalido. Tente novamente.").tipo)
        assertEquals(TipoEcra.DESCONHECIDO, Ecras.classificar("").tipo)
    }

    @Test fun opcaoDoMenuNaoDependeDaOrdem() {
        val outro = "1. Voltar\n5. Servicos de Internet\n2. Por Hora"
        assertEquals("5", Ecras.opcaoDoMenu(outro, "servicos de internet"))
        assertNull(Ecras.opcaoDoMenu(menuInternet, "servicos de internet"))
    }

    // ───── sessão: fluxo completo ─────

    @Test fun fluxoDeSucesso() {
        val s = SessaoUssd(tarefa(100))
        assertEquals("8", enviar(s.aoVerEcra(menuPrincipal)))
        assertEquals("2", enviar(s.aoVerEcra(menuInternet)))
        assertEquals("100", enviar(s.aoVerEcra(pedeQuantidade)))
        assertEquals("857000001", enviar(s.aoVerEcra(pedeDestino)))     // 9 dígitos por omissão
        assertEquals(ResultadoUssd.Sucesso(100, destino, 580), terminar(s.aoVerEcra(sucesso(100, destino))))
    }

    @Test fun destinoCom258QuandoConfigurado() {
        val s = SessaoUssd(tarefa(100), FormatoDestino.COM_258)
        s.aoVerEcra(menuPrincipal); s.aoVerEcra(menuInternet); s.aoVerEcra(pedeQuantidade)
        assertEquals(destino, enviar(s.aoVerEcra(pedeDestino)))
    }

    @Test fun ecraRepetidoNaoEReenviado() {
        val s = SessaoUssd(tarefa())
        assertEquals("8", enviar(s.aoVerEcra(menuPrincipal)))
        assertEquals(Passo.Aguardar, s.aoVerEcra(menuPrincipal))
        assertEquals(Passo.Aguardar, s.aoVerEcra(menuPrincipal.uppercase()))
    }

    @Test fun mesmoTipoDeEcraDuasVezesEhLoop() {
        val s = SessaoUssd(tarefa())
        s.aoVerEcra(menuPrincipal); s.aoVerEcra(menuInternet); s.aoVerEcra(pedeQuantidade)
        // mesmo tipo de ecrã, mas com texto diferente → não reenvia; termina como desconhecido
        val r = terminar(s.aoVerEcra(pedeQuantidade.replace("580", "579")))
        assertTrue(r is ResultadoUssd.Desconhecido)
    }

    // ───── sessão: casos de falha ─────

    @Test fun saldoInsuficienteNaoEnviaNada() {
        val s = SessaoUssd(tarefa(1024))
        s.aoVerEcra(menuPrincipal); s.aoVerEcra(menuInternet)
        assertEquals(ResultadoUssd.SaldoInsuficiente(580), terminar(s.aoVerEcra(pedeQuantidade)))
        assertFalse(s.enviouDestino)
    }

    @Test fun erroMinimoAntesDoDestinoNaoTransferiu() {
        val s = SessaoUssd(tarefa())
        s.aoVerEcra(menuPrincipal); s.aoVerEcra(menuInternet); s.aoVerEcra(pedeQuantidade)
        assertTrue(terminar(s.aoVerEcra(erroMinimo)) is ResultadoUssd.RecusadoAntesDoDestino)
    }

    @Test fun erroMinimoDepoisDoDestinoEAmbiguo() {
        val s = SessaoUssd(tarefa())
        s.aoVerEcra(menuPrincipal); s.aoVerEcra(menuInternet); s.aoVerEcra(pedeQuantidade); s.aoVerEcra(pedeDestino)
        val r = terminar(s.aoVerEcra(erroMinimo)) as ResultadoUssd.Ambiguo
        assertEquals(580, r.saldoAntesMb)
    }

    @Test fun sucessoComValoresDiferentesEDivergente() {
        val s = SessaoUssd(tarefa(100))
        s.aoVerEcra(menuPrincipal); s.aoVerEcra(menuInternet); s.aoVerEcra(pedeQuantidade); s.aoVerEcra(pedeDestino)
        assertTrue(terminar(s.aoVerEcra(sucesso(100, "258857999999"))) is ResultadoUssd.Divergente)
    }

    @Test fun ecraDesconhecidoGuardaSeEnviouDestino() {
        val s = SessaoUssd(tarefa())
        s.aoVerEcra(menuPrincipal); s.aoVerEcra(menuInternet); s.aoVerEcra(pedeQuantidade); s.aoVerEcra(pedeDestino)
        val r = terminar(s.aoVerEcra("Servico indisponivel")) as ResultadoUssd.Desconhecido
        assertTrue(r.enviouDestino)
    }

    @Test fun tempoEsgotado() {
        val s = SessaoUssd(tarefa())
        s.aoVerEcra(menuPrincipal)
        assertEquals(ResultadoUssd.TempoEsgotado(false, null), s.aoExpirar())
    }

    @Test fun consultarSaldo() {
        val s = SessaoUssd(Tarefa.ConsultarSaldo)
        assertEquals("8", enviar(s.aoVerEcra(menuPrincipal)))
        assertEquals("2", enviar(s.aoVerEcra(menuInternet)))
        assertEquals(ResultadoUssd.Saldo(580), terminar(s.aoVerEcra(pedeQuantidade)))
    }

    @Test fun limitesDeMb() {
        assertThrows(IllegalArgumentException::class.java) { Tarefa.Transferir(99, destino) }
        assertThrows(IllegalArgumentException::class.java) { Tarefa.Transferir(10241, destino) }
        assertThrows(IllegalArgumentException::class.java) { Tarefa.Transferir(100, "857000001") }
        Tarefa.Transferir(100, destino); Tarefa.Transferir(10240, destino)
    }

    // ───── ecrã ambíguo: decisão pelo saldo ─────

    @Test fun ambiguo_saldoBaixouOPedido_foiSucesso() =
        assertEquals(DecisaoAmbiguo.SUCESSO, Ambiguo.decidir(580, 480, 100))

    @Test fun ambiguo_saldoBaixouMais_foiSucesso() =
        assertEquals(DecisaoAmbiguo.SUCESSO, Ambiguo.decidir(580, 470, 100))

    @Test fun ambiguo_saldoIgual_foiFalha() =
        assertEquals(DecisaoAmbiguo.FALHA, Ambiguo.decidir(580, 580, 100))

    @Test fun ambiguo_baixouPouco_foiFalha() =
        assertEquals(DecisaoAmbiguo.FALHA, Ambiguo.decidir(580, 575, 100))

    @Test fun ambiguo_meioCaminho_revisao() =
        assertEquals(DecisaoAmbiguo.REVISAO, Ambiguo.decidir(580, 520, 100))

    @Test fun ambiguo_saldoSubiu_revisao() =
        assertEquals(DecisaoAmbiguo.REVISAO, Ambiguo.decidir(580, 700, 100))

    @Test fun ambiguo_semLeitura_revisao() {
        assertEquals(DecisaoAmbiguo.REVISAO, Ambiguo.decidir(null, 500, 100))
        assertEquals(DecisaoAmbiguo.REVISAO, Ambiguo.decidir(580, null, 100))
    }
}
