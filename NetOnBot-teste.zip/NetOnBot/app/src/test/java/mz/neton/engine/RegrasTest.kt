package mz.neton.engine

import mz.neton.data.Familia
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class RegrasTest {

    private fun a(f: Familia?, auto: Set<Familia> = emptySet(), dest: Boolean = false, cli: Boolean = false) =
        Regras.proximaAcao(f, auto, dest, cli)

    @Test fun foraDaTabela_soSms_avisaPorSms() = assertEquals(Acao.SMS_FORA_TABELA, a(null))
    @Test fun foraDaTabela_comCliente_vaiParaCarteira() = assertEquals(Acao.CREDITAR_CARTEIRA, a(null, cli = true))
    @Test fun foraDaTabela_destinoNaoImporta() = assertEquals(Acao.SMS_FORA_TABELA, a(null, dest = true))

    @Test fun diario_comDestino_processaJa() = assertEquals(Acao.PROCESSAR_JA, a(Familia.DIARIO, dest = true))
    @Test fun diario_semDestino_pedePorSms() = assertEquals(Acao.PEDIR_NUMERO_SMS, a(Familia.DIARIO))
    @Test fun diario_semDestino_comCliente_pedeNoGrupo() = assertEquals(Acao.PEDIR_NUMERO_GRUPO, a(Familia.DIARIO, cli = true))
    @Test fun diario_destinoECliente_processaJa() = assertEquals(Acao.PROCESSAR_JA, a(Familia.DIARIO, dest = true, cli = true))
    @Test fun promocao_secomportaComoDiario() = assertEquals(Acao.PEDIR_NUMERO_SMS, a(Familia.PROMOCAO))

    @Test fun semanal_semAtivacaoAutomatica_avisaDono() = assertEquals(Acao.AVISAR_DONO, a(Familia.SEMANAL))
    @Test fun mensal_semAtivacaoAutomatica_avisaDono() = assertEquals(Acao.AVISAR_DONO, a(Familia.MENSAL, dest = true))
    @Test fun semanal_comAtivacaoAutomatica_pedeNumero() =
        assertEquals(Acao.PEDIR_NUMERO_SMS, a(Familia.SEMANAL, auto = setOf(Familia.SEMANAL)))
    @Test fun ativacaoAutomaticaDeUmaFamiliaNaoAbreOutra() =
        assertEquals(Acao.AVISAR_DONO, a(Familia.DIAMANTE, auto = setOf(Familia.SEMANAL)))

    @Test fun extrairNumero() {
        assertEquals("857207022", Regras.extrairNumero("857207022"))
        assertEquals("85 720 7022", Regras.extrairNumero("é o 85 720 7022 obrigado"))
        assertEquals("+258857207022", Regras.extrairNumero("+258857207022"))
        assertNull(Regras.extrairNumero("não sei"))
        assertNull(Regras.extrairNumero("12345"))
    }
}
